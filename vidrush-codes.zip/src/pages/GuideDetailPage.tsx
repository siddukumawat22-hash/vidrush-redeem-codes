import React, { useEffect } from 'react';
import { ArrowLeft, Calendar, Tag, Clock, BookOpen } from 'lucide-react';
import { Article } from '../types';
import { SocialShare } from '../components/SocialShare';
import { AdPlaceholder } from '../components/AdPlaceholder';

interface GuideDetailPageProps {
  article: Article;
  onBack: () => void;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
}

export const GuideDetailPage: React.FC<GuideDetailPageProps> = ({
  article,
  onBack,
  onShowToast
}) => {
  useEffect(() => {
    // Inject JSON-LD Article Schema
    const schemaData = {
      '@context': 'https://schema.org',
      '@type': 'Article',
      'headline': article.seo_title || article.title,
      'description': article.meta_description || article.excerpt,
      'image': [article.featured_image],
      'datePublished': article.created_at,
      'dateModified': article.updated_at,
      'author': {
        '@type': 'Organization',
        'name': 'Vidrush Codes Editorial'
      },
      'publisher': {
        '@type': 'Organization',
        'name': 'Vidrush Codes'
      }
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.id = 'article-schema';
    script.text = JSON.stringify(schemaData);
    document.head.appendChild(script);

    return () => {
      const old = document.getElementById('article-schema');
      if (old) old.remove();
    };
  }, [article]);

  // Convert simple markdown headings & paragraphs to HTML sections
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('### ')) {
        return <h3 key={idx} className="text-xl font-bold text-white mt-6 mb-2">{trimmed.replace('### ', '')}</h3>;
      }
      if (trimmed.startsWith('## ')) {
        return <h2 key={idx} className="text-2xl font-black text-purple-300 mt-8 mb-3">{trimmed.replace('## ', '')}</h2>;
      }
      if (trimmed.startsWith('# ')) {
        return <h1 key={idx} className="text-3xl font-black text-white mt-10 mb-4">{trimmed.replace('# ', '')}</h1>;
      }
      if (trimmed === '') {
        return <div key={idx} className="h-3" />;
      }
      return <p key={idx} className="text-slate-300 text-sm sm:text-base leading-relaxed my-2">{line}</p>;
    });
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-8 py-4">
      
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/40 border border-white/10 backdrop-blur-md text-slate-300 hover:text-white hover:border-white/20 transition-all text-xs"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Back to Guides
      </button>

      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 flex-wrap">
          {article.tags.map((t, idx) => (
            <span key={idx} className="px-2.5 py-0.5 rounded text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              {t}
            </span>
          ))}
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-snug">
          {article.title}
        </h1>

        <div className="flex items-center gap-4 text-xs text-slate-400 border-b border-white/5 pb-4">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-purple-400" />
            {new Date(article.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </span>
          <span>•</span>
          <span>By Vidrush Codes Editorial</span>
        </div>
      </div>

      {/* Featured Image */}
      <div className="rounded-2xl overflow-hidden border border-white/10 max-h-96">
        <img
          src={article.featured_image}
          alt={article.title}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Article Content */}
      <div className="prose prose-invert max-w-none text-slate-300 leading-relaxed space-y-2">
        {renderFormattedContent(article.content)}
      </div>

      {/* Ad Placeholder */}
      <AdPlaceholder />

      {/* Share Component */}
      <SocialShare title={article.title} onShowToast={onShowToast} />
    </div>
  );
};
