import React, { useState } from 'react';
import { Search, Menu, X, ShieldCheck, Sparkles, Key, BookOpen, HelpCircle, Lock } from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onSearchSubmit?: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate, onSearchSubmit }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim() && onSearchSubmit) {
      onSearchSubmit(searchQuery.trim());
      onNavigate('/codes');
      setSearchQuery('');
    }
  };

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Latest Codes', path: '/codes' },
    { label: 'Working Codes', path: '/working-codes' },
    { label: 'Expired Codes', path: '/expired-codes' },
    { label: 'Guides', path: '/guides' },
    { label: 'FAQ', path: '/faq' },
  ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-950/40 border-b border-white/5 shadow-lg shadow-black/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Logo */}
          <div 
            onClick={() => handleLinkClick('/')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/20 group-hover:scale-105 transition-transform duration-200">
              <span className="font-bold text-white italic text-lg">V</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                  Vidrush Codes
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold tracking-wider text-emerald-400 bg-emerald-500/20 border border-emerald-500/30 rounded-full">
                  VERIFIED
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium hidden sm:block">
                Latest Game Promo Vouchers
              </p>
            </div>
          </div>

          {/* Desktop Search Bar */}
          <form onSubmit={handleSearchSubmit} className="hidden lg:flex items-center relative max-w-xs w-full">
            <input
              type="text"
              placeholder="Search codes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/50 border border-white/10 text-slate-100 placeholder-slate-500 text-xs pl-9 pr-4 py-1.5 rounded-full focus:outline-none focus:border-purple-500/50 transition-all"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2 pointer-events-none" />
          </form>

          {/* Navigation Links - Desktop */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => handleLinkClick(link.path)}
                  className={`transition-colors ${
                    isActive
                      ? 'text-white border-b-2 border-purple-500 pb-1 font-semibold'
                      : 'hover:text-white'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}

            <button
              onClick={() => handleLinkClick('/admin')}
              className={`p-2 rounded-lg transition-colors text-slate-400 hover:text-white ${
                currentPath === '/admin' ? 'text-purple-400 border-b-2 border-purple-500 pb-1' : ''
              }`}
              title="Admin Dashboard"
            >
              <Lock className="w-4 h-4" />
            </button>
          </nav>

          {/* Mobile Right Controls */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-950/95 border-b border-purple-900/40 px-4 pt-3 pb-6 space-y-3">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <input
              type="text"
              placeholder="Search redeem codes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 text-slate-200 placeholder-slate-500 text-sm pl-9 pr-4 py-2.5 rounded-xl border border-purple-900/40 focus:outline-none focus:border-purple-500"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </form>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path;
              return (
                <button
                  key={link.path}
                  onClick={() => handleLinkClick(link.path)}
                  className={`text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold ${
                    isActive
                      ? 'text-purple-300 bg-purple-500/20 border border-purple-500/40'
                      : 'text-slate-300 bg-slate-900/60 border border-slate-800/80 hover:bg-slate-900'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
            <button
              onClick={() => handleLinkClick('/admin')}
              className="col-span-2 text-center px-3.5 py-2.5 rounded-xl text-xs font-semibold text-purple-300 bg-purple-950/40 border border-purple-800/40 flex items-center justify-center gap-2"
            >
              <Lock className="w-3.5 h-3.5" /> Admin Dashboard
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
