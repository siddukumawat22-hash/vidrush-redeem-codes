import React, { useState } from 'react';
import { Search, Filter, ArrowUpDown, Key, ShieldCheck } from 'lucide-react';
import { RedeemCode, CodeStatus } from '../types';
import { CodeCard } from '../components/CodeCard';

interface CodesPageProps {
  codes: RedeemCode[];
  initialStatusFilter?: 'All' | CodeStatus;
  onSelectCode: (code: RedeemCode) => void;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
}

export const CodesPage: React.FC<CodesPageProps> = ({
  codes,
  initialStatusFilter = 'All',
  onSelectCode,
  onShowToast
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | CodeStatus>(initialStatusFilter);
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'recently_verified' | 'oldest'>('newest');

  // Extract unique tags
  const allTags = Array.from(
    new Set(codes.flatMap(c => c.tags))
  );

  let filtered = codes.filter(c => {
    const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
    const matchesTag = selectedTag === 'All' || c.tags.some(t => t.toLowerCase() === selectedTag.toLowerCase());
    const q = searchQuery.toLowerCase().trim();
    const matchesQ =
      !q ||
      c.code.toLowerCase().includes(q) ||
      c.title.toLowerCase().includes(q) ||
      c.reward.toLowerCase().includes(q);
    return matchesStatus && matchesTag && matchesQ;
  });

  // Sort
  if (sortBy === 'newest') {
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  } else if (sortBy === 'recently_verified') {
    filtered.sort((a, b) => new Date(b.verified_at).getTime() - new Date(a.verified_at).getTime());
  } else if (sortBy === 'oldest') {
    filtered.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6">
      
      {/* Page Header */}
      <div className="text-center max-w-2xl mx-auto pt-4">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Vidrush Redeem Codes Archive
        </h1>
        <p className="text-slate-400 text-sm mt-2">
          Search, filter, and discover all verified active, unverified, and historical promo vouchers.
        </p>
      </div>

      {/* Search and Filters Bar */}
      <div className="p-5 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          
          {/* Search Box */}
          <div className="md:col-span-2 relative">
            <input
              type="text"
              placeholder="Search code string or reward..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950/60 text-slate-100 placeholder-slate-500 text-xs sm:text-sm pl-9 pr-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-purple-500/50"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-white/10">
            <Filter className="w-3.5 h-3.5 text-purple-400 shrink-0" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
            >
              <option value="All" className="bg-slate-900">All Statuses</option>
              <option value="Working" className="bg-slate-900">Working Only</option>
              <option value="Expired" className="bg-slate-900">Expired Only</option>
              <option value="Unverified" className="bg-slate-900">Unverified Only</option>
            </select>
          </div>

          {/* Sort Control */}
          <div className="flex items-center gap-2 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-white/10">
            <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer"
            >
              <option value="newest" className="bg-slate-900">Newest Added</option>
              <option value="recently_verified" className="bg-slate-900">Recently Verified</option>
              <option value="oldest" className="bg-slate-900">Oldest First</option>
            </select>
          </div>
        </div>

        {/* Tag Pills */}
        {allTags.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pt-2 border-t border-white/5">
            <span className="text-[11px] font-bold text-slate-500 uppercase mr-1 shrink-0">Tags:</span>
            <button
              onClick={() => setSelectedTag('All')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors shrink-0 ${
                selectedTag === 'All' ? 'bg-purple-600 text-white' : 'bg-slate-950/60 border border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              All Tags
            </button>
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors shrink-0 ${
                  selectedTag === tag ? 'bg-purple-600 text-white' : 'bg-slate-950/60 border border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Code List Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl">
          <Key className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="font-bold text-slate-300 text-base">No redeem codes match your search criteria.</h3>
          <p className="text-slate-500 text-xs mt-1">Try clearing your filters or search keywords.</p>
          <button
            onClick={() => { setSearchQuery(''); setStatusFilter('All'); setSelectedTag('All'); }}
            className="mt-4 px-4 py-2 rounded-xl bg-purple-600 text-white text-xs font-bold"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(code => (
            <CodeCard
              key={code.id}
              code={code}
              onSelectCode={onSelectCode}
              onShowToast={onShowToast}
            />
          ))}
        </div>
      )}
    </div>
  );
};
