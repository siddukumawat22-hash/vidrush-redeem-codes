import React, { useState } from 'react';
import { Copy, Check, Calendar, ShieldCheck, Sparkles, Tag, ArrowRight, Eye } from 'lucide-react';
import confetti from 'canvas-confetti';
import { RedeemCode } from '../types';
import { apiService } from '../services/api';

interface CodeCardProps {
  code: RedeemCode;
  onSelectCode: (code: RedeemCode) => void;
  onShowToast: (message: string, type?: 'success' | 'info') => void;
}

export const CodeCard: React.FC<CodeCardProps> = ({ code, onSelectCode, onShowToast }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code.code);
    setCopied(true);
    onShowToast(`Copied "${code.code}" to clipboard!`, 'success');

    // Trigger celebratory confetti burst
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#a855f7', '#6366f1', '#38bdf8']
      });
    } catch {}

    // Track copy on server
    apiService.trackCodeCopy(code.id);

    setTimeout(() => {
      setCopied(false);
    }, 2500);
  };

  const getStatusBadge = () => {
    switch (code.status) {
      case 'Working':
        return (
          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-[10px] font-bold rounded uppercase tracking-wider border border-green-500/30">
            Working
          </span>
        );
      case 'Expired':
        return (
          <span className="px-2 py-1 bg-red-500/20 text-red-400 text-[10px] font-bold rounded uppercase tracking-wider border border-red-500/30">
            Expired
          </span>
        );
      case 'Unverified':
      default:
        return (
          <span className="px-2 py-1 bg-amber-500/20 text-amber-400 text-[10px] font-bold rounded uppercase tracking-wider border border-amber-500/30">
            Unverified
          </span>
        );
    }
  };

  const formattedVerifiedDate = new Date(code.verified_at).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div 
      onClick={() => onSelectCode(code)}
      className={`bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl p-6 relative group overflow-hidden transition-all hover:bg-slate-900/60 hover:border-white/20 flex flex-col justify-between cursor-pointer ${
        code.status === 'Expired' ? 'opacity-80' : ''
      }`}
    >
      {code.featured && (
        <div className="absolute top-0 left-0 px-3 py-1 bg-purple-500/30 border-b border-r border-purple-500/40 text-purple-200 text-[10px] font-extrabold uppercase tracking-widest rounded-br-xl backdrop-blur-md flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-cyan-300" /> FEATURED
        </div>
      )}

      <div className="absolute top-0 right-0 p-3">
        {getStatusBadge()}
      </div>

      <div className="mt-4 mb-4">
        <p className="text-slate-500 text-[10px] uppercase font-bold tracking-widest mb-1">Redeem Code</p>
        <h3 className={`text-2xl font-mono font-bold tracking-wider ${code.status === 'Expired' ? 'text-white/50 line-through' : 'text-white'}`}>
          {code.code}
        </h3>
        <p className="text-xs text-slate-300 mt-2 line-clamp-1">
          <span className="text-slate-400">Reward:</span> {code.reward}
        </p>
      </div>

      <div className="flex flex-col gap-1 mb-5 text-xs text-slate-400 border-t border-white/5 pt-3">
        <div className="flex justify-between">
          <span>Title:</span>
          <span className="text-slate-200 font-medium line-clamp-1">{code.title}</span>
        </div>
        <div className="flex justify-between">
          <span>Verified:</span>
          <span className="text-slate-200">{formattedVerifiedDate}</span>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          onClick={handleCopy}
          disabled={code.status === 'Expired'}
          className={`flex-1 text-xs font-bold py-2.5 rounded-lg transition-all ${
            code.status === 'Expired'
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
              : copied
              ? 'bg-emerald-500 text-slate-950 font-black'
              : 'bg-white text-slate-900 hover:bg-slate-200'
          }`}
        >
          {copied ? 'COPIED ✓' : code.status === 'Expired' ? 'EXPIRED' : 'COPY CODE'}
        </button>
        <button 
          onClick={() => onSelectCode(code)}
          className="p-2.5 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors text-white"
          title="View Details"
        >
          <Eye className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
};
