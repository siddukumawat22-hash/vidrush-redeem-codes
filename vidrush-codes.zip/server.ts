import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { INITIAL_CODES, INITIAL_ARTICLES, INITIAL_SETTINGS } from './src/data/seedData';
import { RedeemCode, Article, SiteSettings, AnalyticsStats } from './src/types';

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Path for JSON File DB
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

interface LocalDB {
  codes: RedeemCode[];
  articles: Article[];
  settings: SiteSettings;
  stats: AnalyticsStats;
}

// Initialize File DB
function getDB(): LocalDB {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      const defaultStats: AnalyticsStats = {
        totalCodes: INITIAL_CODES.length,
        workingCodes: INITIAL_CODES.filter(c => c.status === 'Working').length,
        expiredCodes: INITIAL_CODES.filter(c => c.status === 'Expired').length,
        unverifiedCodes: INITIAL_CODES.filter(c => c.status === 'Unverified').length,
        totalArticles: INITIAL_ARTICLES.length,
        totalCopies: 5800,
        totalPageViews: 18450,
        recentActivity: [
          {
            id: 'act-1',
            type: 'code_added',
            message: 'Code VIDRUSH2026 published',
            timestamp: new Date().toISOString()
          },
          {
            id: 'act-2',
            type: 'code_verified',
            message: 'Code VIPGIFT888 marked Working',
            timestamp: new Date(Date.now() - 3600000).toISOString()
          }
        ]
      };
      const initialDb: LocalDB = {
        codes: INITIAL_CODES,
        articles: INITIAL_ARTICLES,
        settings: INITIAL_SETTINGS,
        stats: defaultStats
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), 'utf-8');
      return initialDb;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading db.json, falling back to seed:', err);
    return {
      codes: INITIAL_CODES,
      articles: INITIAL_ARTICLES,
      settings: INITIAL_SETTINGS,
      stats: {
        totalCodes: INITIAL_CODES.length,
        workingCodes: INITIAL_CODES.filter(c => c.status === 'Working').length,
        expiredCodes: INITIAL_CODES.filter(c => c.status === 'Expired').length,
        unverifiedCodes: INITIAL_CODES.filter(c => c.status === 'Unverified').length,
        totalArticles: INITIAL_ARTICLES.length,
        totalCopies: 5800,
        totalPageViews: 18450,
        recentActivity: []
      }
    };
  }
}

function saveDB(db: LocalDB): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    // Update count stats dynamically
    db.stats.totalCodes = db.codes.length;
    db.stats.workingCodes = db.codes.filter(c => c.status === 'Working').length;
    db.stats.expiredCodes = db.codes.filter(c => c.status === 'Expired').length;
    db.stats.unverifiedCodes = db.codes.filter(c => c.status === 'Unverified').length;
    db.stats.totalArticles = db.articles.length;

    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving db.json:', err);
  }
}

// Simple Admin Auth middleware helper
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123456';

function verifyAdminToken(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.replace('Bearer ', '').trim() === 'vidrush-admin-secret-token') {
    return next();
  }
  return res.status(401).json({ error: 'Unauthorized admin access' });
}

// --- API ENDPOINTS ---

// Admin Login
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    return res.json({
      success: true,
      token: 'vidrush-admin-secret-token',
      user: { role: 'admin', email: 'admin@vidrushcodes.com' }
    });
  }
  return res.status(401).json({ success: false, error: 'Invalid admin password' });
});

// GET All Codes
app.get('/api/codes', (req, res) => {
  const db = getDB();
  let result = [...db.codes];

  const q = (req.query.q as string || '').toLowerCase().trim();
  const status = req.query.status as string;
  const tag = req.query.tag as string;
  const sortBy = req.query.sortBy as string || 'newest';
  const featured = req.query.featured;

  if (q) {
    result = result.filter(c =>
      c.code.toLowerCase().includes(q) ||
      c.title.toLowerCase().includes(q) ||
      c.reward.toLowerCase().includes(q) ||
      c.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  if (status && status !== 'All') {
    result = result.filter(c => c.status === status);
  }

  if (tag) {
    result = result.filter(c => c.tags.some(t => t.toLowerCase() === tag.toLowerCase()));
  }

  if (featured === 'true') {
    result = result.filter(c => c.featured);
  }

  // Sorting
  if (sortBy === 'newest') {
    result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  } else if (sortBy === 'recently_verified') {
    result.sort((a, b) => new Date(b.verified_at).getTime() - new Date(a.verified_at).getTime());
  } else if (sortBy === 'oldest') {
    result.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  }

  res.json({
    codes: result,
    total: result.length,
    counts: {
      total: db.codes.length,
      working: db.codes.filter(c => c.status === 'Working').length,
      expired: db.codes.filter(c => c.status === 'Expired').length,
      unverified: db.codes.filter(c => c.status === 'Unverified').length
    }
  });
});

// GET Single Code by Slug or ID
app.get('/api/codes/:slugOrId', (req, res) => {
  const db = getDB();
  const param = req.params.slugOrId.toLowerCase();
  const codeIndex = db.codes.findIndex(c => c.slug.toLowerCase() === param || c.id === param);

  if (codeIndex === -1) {
    return res.status(404).json({ error: 'Redeem code not found' });
  }

  // Increment view count
  db.codes[codeIndex].viewCount = (db.codes[codeIndex].viewCount || 0) + 1;
  db.stats.totalPageViews += 1;
  saveDB(db);

  res.json(db.codes[codeIndex]);
});

// Track Code Copy Event
app.post('/api/codes/:id/copy', (req, res) => {
  const db = getDB();
  const code = db.codes.find(c => c.id === req.params.id);
  if (code) {
    code.copyCount = (code.copyCount || 0) + 1;
    db.stats.totalCopies += 1;
    saveDB(db);
  }
  res.json({ success: true, copyCount: code ? code.copyCount : 0 });
});

// Admin ADD Code
app.post('/api/codes', verifyAdminToken, (req, res) => {
  const db = getDB();
  const body = req.body;

  if (!body.code || !body.title) {
    return res.status(400).json({ error: 'Code and Title are required' });
  }

  const rawCode = body.code.trim().toUpperCase();
  const slug = body.slug || rawCode.toLowerCase().replace(/[^a-z0-9]+/g, '-');

  const newCode: RedeemCode = {
    id: 'code-' + Date.now(),
    code: rawCode,
    slug,
    title: body.title,
    description: body.description || '',
    reward: body.reward || 'Special Rewards',
    status: body.status || 'Working',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    verified_at: body.verified_at || new Date().toISOString(),
    expires_at: body.expires_at || undefined,
    featured: Boolean(body.featured),
    tags: Array.isArray(body.tags) ? body.tags : (body.tags ? body.tags.split(',').map((t: string) => t.trim()) : ['Rewards']),
    copyCount: 0,
    viewCount: 0
  };

  db.codes.unshift(newCode);
  db.stats.recentActivity.unshift({
    id: 'act-' + Date.now(),
    type: 'code_added',
    message: `Code ${newCode.code} added (${newCode.status})`,
    timestamp: new Date().toISOString()
  });

  saveDB(db);
  res.status(201).json(newCode);
});

// Admin UPDATE Code
app.put('/api/codes/:id', verifyAdminToken, (req, res) => {
  const db = getDB();
  const index = db.codes.findIndex(c => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Code not found' });
  }

  const existing = db.codes[index];
  const body = req.body;

  const updated: RedeemCode = {
    ...existing,
    code: body.code ? body.code.trim().toUpperCase() : existing.code,
    title: body.title !== undefined ? body.title : existing.title,
    description: body.description !== undefined ? body.description : existing.description,
    reward: body.reward !== undefined ? body.reward : existing.reward,
    status: body.status !== undefined ? body.status : existing.status,
    verified_at: body.verified_at !== undefined ? body.verified_at : existing.verified_at,
    expires_at: body.expires_at !== undefined ? body.expires_at : existing.expires_at,
    featured: body.featured !== undefined ? Boolean(body.featured) : existing.featured,
    tags: Array.isArray(body.tags) ? body.tags : (typeof body.tags === 'string' ? body.tags.split(',').map((t: string) => t.trim()) : existing.tags),
    updated_at: new Date().toISOString()
  };

  db.codes[index] = updated;

  db.stats.recentActivity.unshift({
    id: 'act-' + Date.now(),
    type: 'code_verified',
    message: `Code ${updated.code} status updated to ${updated.status}`,
    timestamp: new Date().toISOString()
  });

  saveDB(db);
  res.json(updated);
});

// Admin DELETE Code
app.delete('/api/codes/:id', verifyAdminToken, (req, res) => {
  const db = getDB();
  const index = db.codes.findIndex(c => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Code not found' });
  }

  const deleted = db.codes.splice(index, 1)[0];
  saveDB(db);
  res.json({ success: true, deletedId: deleted.id });
});

// GET Articles
app.get('/api/articles', (req, res) => {
  const db = getDB();
  res.json(db.articles);
});

// GET Single Article
app.get('/api/articles/:slug', (req, res) => {
  const db = getDB();
  const article = db.articles.find(a => a.slug === req.params.slug || a.id === req.params.slug);
  if (!article) {
    return res.status(404).json({ error: 'Article not found' });
  }
  res.json(article);
});

// Admin ADD Article
app.post('/api/articles', verifyAdminToken, (req, res) => {
  const db = getDB();
  const body = req.body;

  if (!body.title || !body.content) {
    return res.status(400).json({ error: 'Title and Content are required' });
  }

  const slug = body.slug || body.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const newArticle: Article = {
    id: 'art-' + Date.now(),
    title: body.title,
    slug,
    excerpt: body.excerpt || '',
    content: body.content,
    featured_image: body.featured_image || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    seo_title: body.seo_title || body.title,
    meta_description: body.meta_description || body.excerpt,
    tags: Array.isArray(body.tags) ? body.tags : (body.tags ? body.tags.split(',').map((t: string) => t.trim()) : ['Guide']),
    published: body.published !== undefined ? Boolean(body.published) : true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  db.articles.unshift(newArticle);
  db.stats.recentActivity.unshift({
    id: 'act-' + Date.now(),
    type: 'article_published',
    message: `Article "${newArticle.title}" published`,
    timestamp: new Date().toISOString()
  });

  saveDB(db);
  res.status(201).json(newArticle);
});

// Admin UPDATE Article
app.put('/api/articles/:id', verifyAdminToken, (req, res) => {
  const db = getDB();
  const index = db.articles.findIndex(a => a.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Article not found' });
  }

  const body = req.body;
  db.articles[index] = {
    ...db.articles[index],
    title: body.title !== undefined ? body.title : db.articles[index].title,
    excerpt: body.excerpt !== undefined ? body.excerpt : db.articles[index].excerpt,
    content: body.content !== undefined ? body.content : db.articles[index].content,
    featured_image: body.featured_image !== undefined ? body.featured_image : db.articles[index].featured_image,
    seo_title: body.seo_title !== undefined ? body.seo_title : db.articles[index].seo_title,
    meta_description: body.meta_description !== undefined ? body.meta_description : db.articles[index].meta_description,
    tags: Array.isArray(body.tags) ? body.tags : (typeof body.tags === 'string' ? body.tags.split(',').map((t: string) => t.trim()) : db.articles[index].tags),
    published: body.published !== undefined ? Boolean(body.published) : db.articles[index].published,
    updated_at: new Date().toISOString()
  };

  saveDB(db);
  res.json(db.articles[index]);
});

// Admin DELETE Article
app.delete('/api/articles/:id', verifyAdminToken, (req, res) => {
  const db = getDB();
  const index = db.articles.findIndex(a => a.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Article not found' });
  }
  const deleted = db.articles.splice(index, 1)[0];
  saveDB(db);
  res.json({ success: true, deletedId: deleted.id });
});

// GET Settings
app.get('/api/settings', (req, res) => {
  const db = getDB();
  res.json(db.settings);
});

// Admin UPDATE Settings
app.put('/api/settings', verifyAdminToken, (req, res) => {
  const db = getDB();
  db.settings = { ...db.settings, ...req.body };
  saveDB(db);
  res.json(db.settings);
});

// GET Stats
app.get('/api/stats', (req, res) => {
  const db = getDB();
  res.json(db.stats);
});

// Dynamic SEO Sitemap
app.get('/sitemap.xml', (req, res) => {
  const db = getDB();
  const baseUrl = process.env.APP_URL || 'https://vidrushcodes.com';

  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xml += `<urlset xmlns="http://www.sitemapindex.org/schemas/sitemap/0.9">\n`;

  // Static pages
  const staticPages = ['', '/codes', '/working-codes', '/expired-codes', '/guides', '/faq', '/privacy-policy', '/terms-and-conditions', '/disclaimer', '/contact-us'];
  staticPages.forEach(p => {
    xml += `  <url>\n    <loc>${baseUrl}${p}</loc>\n    <changefreq>daily</changefreq>\n    <priority>${p === '' ? '1.0' : '0.8'}</priority>\n  </url>\n`;
  });

  // Code details
  db.codes.forEach(c => {
    xml += `  <url>\n    <loc>${baseUrl}/codes/${c.slug}</loc>\n    <lastmod>${c.updated_at.split('T')[0]}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>0.9</priority>\n  </url>\n`;
  });

  // Articles
  db.articles.forEach(a => {
    if (a.published) {
      xml += `  <url>\n    <loc>${baseUrl}/guides/${a.slug}</loc>\n    <lastmod>${a.updated_at.split('T')[0]}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n  </url>\n`;
    }
  });

  xml += `</urlset>`;
  res.header('Content-Type', 'application/xml');
  res.send(xml);
});

// SEO Robots.txt
app.get('/robots.txt', (req, res) => {
  const baseUrl = process.env.APP_URL || 'https://vidrushcodes.com';
  const txt = `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\nSitemap: ${baseUrl}/sitemap.xml\n`;
  res.header('Content-Type', 'text/plain');
  res.send(txt);
});

// Start Express + Vite
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Vidrush Codes server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
