import React from 'react';
import { Home, KeyRound } from 'lucide-react';

interface NotFoundPageProps {
  onNavigate: (path: string) => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-md mx-auto my-16 text-center space-y-6 px-4">
      <div className="w-16 h-16 rounded-3xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center mx-auto text-purple-400">
        <KeyRound className="w-8 h-8" />
      </div>

      <div className="space-y-2">
        <h1 className="text-4xl font-extrabold text-white">404 - Page Not Found</h1>
        <p className="text-slate-400 text-sm leading-relaxed">
          The redeem code or page you requested does not exist or has been relocated.
        </p>
      </div>

      <button
        onClick={() => onNavigate('/')}
        className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs inline-flex items-center gap-2 transition-colors shadow-lg"
      >
        <Home className="w-4 h-4" /> Return to Homepage
      </button>
    </div>
  );
};
