import React from 'react';
import { BookOpen, Clock, Tag, ArrowRight } from 'lucide-react';
import { Article } from '../types';

interface GuidesPageProps {
  articles: Article[];
  onSelectArticle: (article: Article) => void;
}

export const GuidesPage: React.FC<GuidesPageProps> = ({ articles, onSelectArticle }) => {
  const publishedArticles = articles.filter(a => a.published);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8 py-4">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20 mb-3">
          <BookOpen className="w-3.5 h-3.5" /> OFFICIAL REDEMPTION GUIDES
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Vidrush Guides & Strategy Articles
        </h1>
        <p className="text-slate-400 text-sm mt-2">
          Step-by-step tutorials, code expiration rules, and tips to maximize your free rewards.
        </p>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {publishedArticles.map((article) => (
          <div
            key={article.id}
            onClick={() => onSelectArticle(article)}
            className="group rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md overflow-hidden hover:bg-slate-900/60 hover:border-white/20 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="h-48 overflow-hidden relative">
                <img
                  src={article.featured_image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
              </div>
              <div className="p-5 space-y-2">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {article.tags.map((t, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {t}
                    </span>
                  ))}
                </div>
                <h2 className="font-bold text-white text-lg group-hover:text-purple-300 transition-colors line-clamp-2">
                  {article.title}
                </h2>
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed">
                  {article.excerpt}
                </p>
              </div>
            </div>

            <div className="p-5 pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-white/5">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-purple-400" />
                {new Date(article.created_at).toLocaleDateString()}
              </span>
              <span className="text-purple-400 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                Read Guide <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
