import React from 'react';
import { FAQSection } from '../components/FAQSection';
import { HowToRedeem } from '../components/HowToRedeem';

export const FAQPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-12 py-4">
      <FAQSection />
      <HowToRedeem />
    </div>
  );
};
