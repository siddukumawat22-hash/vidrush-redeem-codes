import { RedeemCode, Article, SiteSettings, AnalyticsStats, SearchFilters, CodeStatus } from '../types';
import { INITIAL_CODES, INITIAL_ARTICLES, INITIAL_SETTINGS } from '../data/seedData';

const LOCAL_STORAGE_KEY_ADMIN_TOKEN = 'vidrush_admin_token';

export const apiService = {
  // Admin Token helpers
  getAdminToken(): string | null {
    return localStorage.getItem(LOCAL_STORAGE_KEY_ADMIN_TOKEN);
  },

  setAdminToken(token: string): void {
    localStorage.setItem(LOCAL_STORAGE_KEY_ADMIN_TOKEN, token);
  },

  clearAdminToken(): void {
    localStorage.removeItem(LOCAL_STORAGE_KEY_ADMIN_TOKEN);
  },

  async loginAdmin(password: string): Promise<{ success: boolean; token?: string; error?: string }> {
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        this.setAdminToken(data.token);
        return { success: true, token: data.token };
      }
      return { success: false, error: data.error || 'Login failed' };
    } catch {
      // Fallback local check
      if (password === 'admin123456') {
        const token = 'vidrush-admin-secret-token';
        this.setAdminToken(token);
        return { success: true, token };
      }
      return { success: false, error: 'Connection error and password invalid' };
    }
  },

  // GET Codes
  async getCodes(filters?: Partial<SearchFilters>): Promise<{
    codes: RedeemCode[];
    total: number;
    counts: { total: number; working: number; expired: number; unverified: number };
  }> {
    try {
      const params = new URLSearchParams();
      if (filters?.query) params.append('q', filters.query);
      if (filters?.status) params.append('status', filters.status);
      if (filters?.sortBy) params.append('sortBy', filters.sortBy);
      if (filters?.tag) params.append('tag', filters.tag);

      const res = await fetch(`/api/codes?${params.toString()}`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('API getCodes failed, using fallback:', e);
    }

    // Client side fallback calculation
    let list = [...INITIAL_CODES];
    if (filters?.query) {
      const q = filters.query.toLowerCase();
      list = list.filter(c =>
        c.code.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.reward.toLowerCase().includes(q)
      );
    }
    if (filters?.status && filters.status !== 'All') {
      list = list.filter(c => c.status === filters.status);
    }
    return {
      codes: list,
      total: list.length,
      counts: {
        total: INITIAL_CODES.length,
        working: INITIAL_CODES.filter(c => c.status === 'Working').length,
        expired: INITIAL_CODES.filter(c => c.status === 'Expired').length,
        unverified: INITIAL_CODES.filter(c => c.status === 'Unverified').length
      }
    };
  },

  // GET Single Code
  async getCodeBySlug(slug: string): Promise<RedeemCode | null> {
    try {
      const res = await fetch(`/api/codes/${slug}`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      console.warn('API getCodeBySlug failed:', e);
    }
    const found = INITIAL_CODES.find(c => c.slug.toLowerCase() === slug.toLowerCase() || c.id === slug);
    return found || null;
  },

  // Track Copy Code Event
  async trackCodeCopy(codeId: string): Promise<number> {
    try {
      const res = await fetch(`/api/codes/${codeId}/copy`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        return data.copyCount;
      }
    } catch (e) {
      console.warn('API trackCodeCopy failed:', e);
    }
    return 1;
  },

  // Admin ADD Code
  async addCode(codeData: Partial<RedeemCode>): Promise<RedeemCode> {
    const token = this.getAdminToken();
    const res = await fetch('/api/codes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(codeData)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to add code');
    }
    return await res.json();
  },

  // Admin UPDATE Code
  async updateCode(id: string, codeData: Partial<RedeemCode>): Promise<RedeemCode> {
    const token = this.getAdminToken();
    const res = await fetch(`/api/codes/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(codeData)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update code');
    }
    return await res.json();
  },

  // Admin DELETE Code
  async deleteCode(id: string): Promise<boolean> {
    const token = this.getAdminToken();
    const res = await fetch(`/api/codes/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to delete code');
    }
    return true;
  },

  // GET Articles
  async getArticles(): Promise<Article[]> {
    try {
      const res = await fetch('/api/articles');
      if (res.ok) return await res.json();
    } catch (e) {
      console.warn('API getArticles failed:', e);
    }
    return INITIAL_ARTICLES;
  },

  // GET Article By Slug
  async getArticleBySlug(slug: string): Promise<Article | null> {
    try {
      const res = await fetch(`/api/articles/${slug}`);
      if (res.ok) return await res.json();
    } catch (e) {
      console.warn('API getArticleBySlug failed:', e);
    }
    return INITIAL_ARTICLES.find(a => a.slug === slug || a.id === slug) || null;
  },

  // Admin ADD Article
  async addArticle(articleData: Partial<Article>): Promise<Article> {
    const token = this.getAdminToken();
    const res = await fetch('/api/articles', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(articleData)
    });
    if (!res.ok) throw new Error('Failed to create article');
    return await res.json();
  },

  // Admin UPDATE Article
  async updateArticle(id: string, articleData: Partial<Article>): Promise<Article> {
    const token = this.getAdminToken();
    const res = await fetch(`/api/articles/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(articleData)
    });
    if (!res.ok) throw new Error('Failed to update article');
    return await res.json();
  },

  // Admin DELETE Article
  async deleteArticle(id: string): Promise<boolean> {
    const token = this.getAdminToken();
    const res = await fetch(`/api/articles/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to delete article');
    return true;
  },

  // GET Settings
  async getSettings(): Promise<SiteSettings> {
    try {
      const res = await fetch('/api/settings');
      if (res.ok) return await res.json();
    } catch (e) {
      console.warn('API getSettings failed:', e);
    }
    return INITIAL_SETTINGS;
  },

  // Admin UPDATE Settings
  async updateSettings(settings: Partial<SiteSettings>): Promise<SiteSettings> {
    const token = this.getAdminToken();
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(settings)
    });
    if (!res.ok) throw new Error('Failed to save site settings');
    return await res.json();
  },

  // GET Analytics Stats
  async getStats(): Promise<AnalyticsStats> {
    try {
      const res = await fetch('/api/stats');
      if (res.ok) return await res.json();
    } catch (e) {
      console.warn('API getStats failed:', e);
    }
    return {
      totalCodes: INITIAL_CODES.length,
      workingCodes: INITIAL_CODES.filter(c => c.status === 'Working').length,
      expiredCodes: INITIAL_CODES.filter(c => c.status === 'Expired').length,
      unverifiedCodes: INITIAL_CODES.filter(c => c.status === 'Unverified').length,
      totalArticles: INITIAL_ARTICLES.length,
      totalCopies: 5800,
      totalPageViews: 18450,
      recentActivity: []
    };
  }
};
