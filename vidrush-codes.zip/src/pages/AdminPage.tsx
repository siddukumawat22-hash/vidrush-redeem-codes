import React, { useState, useEffect } from 'react';
import { Lock, LayoutDashboard, Plus, ListFilter, FileText, Settings, Check, Trash2, Edit3, ShieldAlert, Key, Sparkles, LogOut, Eye, CheckCircle, RefreshCw } from 'lucide-react';
import { RedeemCode, Article, SiteSettings, AnalyticsStats, CodeStatus } from '../types';
import { apiService } from '../services/api';

interface AdminPageProps {
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
  onRefreshData: () => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ onShowToast, onRefreshData }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<'overview' | 'add_code' | 'manage_codes' | 'articles' | 'settings'>('overview');

  // Stats & Data
  const [stats, setStats] = useState<AnalyticsStats | null>(null);
  const [codes, setCodes] = useState<RedeemCode[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);

  // Form states - Code
  const [codeForm, setCodeForm] = useState({
    code: '',
    title: '',
    slug: '',
    description: '',
    reward: '',
    status: 'Working' as CodeStatus,
    expires_at: '',
    featured: false,
    tags: 'Gems, Boosters'
  });
  const [editingCodeId, setEditingCodeId] = useState<string | null>(null);

  // Form states - Article
  const [articleForm, setArticleForm] = useState({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    featured_image: '',
    seo_title: '',
    meta_description: '',
    tags: 'Guide, Tutorial',
    published: true
  });
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);

  // Form states - Settings
  const [settingsForm, setSettingsForm] = useState<SiteSettings | null>(null);

  // Search filter inside manage tab
  const [manageSearch, setManageSearch] = useState('');

  useEffect(() => {
    // Check token on mount
    const token = apiService.getAdminToken();
    if (token) {
      setIsAuthenticated(true);
      loadAdminData();
    }
  }, []);

  const loadAdminData = async () => {
    try {
      const [sData, cData, aData, stData] = await Promise.all([
        apiService.getStats(),
        apiService.getCodes(),
        apiService.getArticles(),
        apiService.getSettings()
      ]);
      setStats(sData);
      setCodes(cData.codes);
      setArticles(aData);
      setSiteSettings(stData);
      setSettingsForm(stData);
    } catch (e) {
      console.error('Failed to load admin data:', e);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const res = await apiService.loginAdmin(password);
    if (res.success) {
      setIsAuthenticated(true);
      onShowToast('Welcome Admin!', 'success');
      loadAdminData();
    } else {
      setLoginError(res.error || 'Invalid admin password');
    }
  };

  const handleLogout = () => {
    apiService.clearAdminToken();
    setIsAuthenticated(false);
    onShowToast('Logged out of admin session', 'info');
  };

  // --- CODE HANDLERS ---
  const handleSaveCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeForm.code || !codeForm.title) {
      onShowToast('Code string and Title are required', 'info');
      return;
    }

    try {
      if (editingCodeId) {
        await apiService.updateCode(editingCodeId, {
          ...codeForm,
          tags: codeForm.tags.split(',').map(t => t.trim())
        });
        onShowToast('Code updated successfully!', 'success');
        setEditingCodeId(null);
      } else {
        await apiService.addCode({
          ...codeForm,
          tags: codeForm.tags.split(',').map(t => t.trim())
        });
        onShowToast('New redeem code published!', 'success');
      }

      // Reset
      setCodeForm({
        code: '',
        title: '',
        slug: '',
        description: '',
        reward: '',
        status: 'Working',
        expires_at: '',
        featured: false,
        tags: 'Gems, Boosters'
      });
      loadAdminData();
      onRefreshData();
      setActiveTab('manage_codes');
    } catch (err: any) {
      onShowToast(err.message || 'Error saving code', 'info');
    }
  };

  const handleMarkVerifiedToday = async (code: RedeemCode) => {
    try {
      await apiService.updateCode(code.id, {
        verified_at: new Date().toISOString()
      });
      onShowToast(`Marked ${code.code} verified today!`, 'success');
      loadAdminData();
      onRefreshData();
    } catch (err) {
      onShowToast('Error updating verification date', 'info');
    }
  };

  const handleStatusToggle = async (code: RedeemCode, newStatus: CodeStatus) => {
    try {
      await apiService.updateCode(code.id, { status: newStatus });
      onShowToast(`Updated ${code.code} status to ${newStatus}`, 'success');
      loadAdminData();
      onRefreshData();
    } catch (err) {
      onShowToast('Error changing status', 'info');
    }
  };

  const handleDeleteCode = async (id: string, codeStr: string) => {
    if (!confirm(`Are you sure you want to delete code "${codeStr}"?`)) return;
    try {
      await apiService.deleteCode(id);
      onShowToast(`Deleted code ${codeStr}`, 'success');
      loadAdminData();
      onRefreshData();
    } catch (err) {
      onShowToast('Error deleting code', 'info');
    }
  };

  const startEditCode = (code: RedeemCode) => {
    setEditingCodeId(code.id);
    setCodeForm({
      code: code.code,
      title: code.title,
      slug: code.slug,
      description: code.description,
      reward: code.reward,
      status: code.status,
      expires_at: code.expires_at ? code.expires_at.split('T')[0] : '',
      featured: code.featured,
      tags: code.tags.join(', ')
    });
    setActiveTab('add_code');
  };

  // --- ARTICLE HANDLERS ---
  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!articleForm.title || !articleForm.content) {
      onShowToast('Title and Content required', 'info');
      return;
    }
    try {
      if (editingArticleId) {
        await apiService.updateArticle(editingArticleId, {
          ...articleForm,
          tags: articleForm.tags.split(',').map(t => t.trim())
        });
        onShowToast('Article updated!', 'success');
        setEditingArticleId(null);
      } else {
        await apiService.addArticle({
          ...articleForm,
          tags: articleForm.tags.split(',').map(t => t.trim())
        });
        onShowToast('Article published!', 'success');
      }
      setArticleForm({
        title: '',
        slug: '',
        excerpt: '',
        content: '',
        featured_image: '',
        seo_title: '',
        meta_description: '',
        tags: 'Guide, Tutorial',
        published: true
      });
      loadAdminData();
      onRefreshData();
    } catch (err) {
      onShowToast('Failed to save article', 'info');
    }
  };

  const handleDeleteArticle = async (id: string, title: string) => {
    if (!confirm(`Delete article "${title}"?`)) return;
    try {
      await apiService.deleteArticle(id);
      onShowToast(`Deleted article "${title}"`, 'success');
      loadAdminData();
      onRefreshData();
    } catch (err) {
      onShowToast('Failed to delete article', 'info');
    }
  };

  // --- SETTINGS HANDLERS ---
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm) return;
    try {
      await apiService.updateSettings(settingsForm);
      onShowToast('Site Settings saved successfully!', 'success');
      loadAdminData();
      onRefreshData();
    } catch (err) {
      onShowToast('Error saving site settings', 'info');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-12 p-8 rounded-3xl bg-slate-900/40 border border-white/10 backdrop-blur-md shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 p-0.5 mx-auto">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Lock className="w-6 h-6 text-purple-400" />
            </div>
          </div>
          <h1 className="text-2xl font-extrabold text-white">Vidrush Admin Authentication</h1>
          <p className="text-xs text-slate-400">
            Enter admin security password to access code publishing dashboard.
          </p>
        </div>

        {loginError && (
          <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs font-semibold text-center">
            {loginError}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Admin Password</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-950/60 text-slate-100 text-sm p-3 rounded-xl border border-white/10 focus:outline-none focus:border-purple-500/50"
              required
            />
            <span className="text-[10px] text-slate-500 mt-1 block">
              Default password: <code className="text-purple-400">admin123456</code> (configurable in .env)
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm shadow-lg shadow-purple-950/80 transition-all"
          >
            Authenticate Session
          </button>
        </form>
      </div>
    );
  }

  const filteredManageCodes = codes.filter(c =>
    c.code.toLowerCase().includes(manageSearch.toLowerCase()) ||
    c.title.toLowerCase().includes(manageSearch.toLowerCase()) ||
    c.reward.toLowerCase().includes(manageSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8 py-4">
      
      {/* Top Admin Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-extrabold text-white text-lg">Vidrush Codes Admin Portal</h1>
            <p className="text-xs text-slate-400">Manage codes, status verification, and article guides</p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="px-3.5 py-1.5 rounded-xl bg-rose-950/40 border border-rose-800/40 text-rose-300 hover:bg-rose-900/40 text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto"
        >
          <LogOut className="w-3.5 h-3.5" /> Log Out
        </button>
      </div>

      {/* Nav Tabs */}
      <div className="flex items-center gap-2 border-b border-white/5 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'overview' ? 'bg-purple-600 text-white shadow-md' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" /> Overview
        </button>

        <button
          onClick={() => { setEditingCodeId(null); setActiveTab('add_code'); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'add_code' ? 'bg-purple-600 text-white shadow-md' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          <Plus className="w-4 h-4" /> {editingCodeId ? 'Edit Code' : 'Add Code'}
        </button>

        <button
          onClick={() => setActiveTab('manage_codes')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'manage_codes' ? 'bg-purple-600 text-white shadow-md' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          <ListFilter className="w-4 h-4" /> Manage Codes ({codes.length})
        </button>

        <button
          onClick={() => setActiveTab('articles')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'articles' ? 'bg-purple-600 text-white shadow-md' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4" /> Articles / Guides ({articles.length})
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
            activeTab === 'settings' ? 'bg-purple-600 text-white shadow-md' : 'bg-white/5 border border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          <Settings className="w-4 h-4" /> Site & Ad Settings
        </button>
      </div>

      {/* --- OVERVIEW TAB --- */}
      {activeTab === 'overview' && stats && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold block">Total Redeem Codes</span>
              <span className="text-2xl sm:text-3xl font-black text-white mt-1 block">{stats.totalCodes}</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-900/40">
              <span className="text-xs text-emerald-400 font-semibold block">Working Codes</span>
              <span className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1 block">{stats.workingCodes}</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-rose-900/40">
              <span className="text-xs text-rose-400 font-semibold block">Expired Codes</span>
              <span className="text-2xl sm:text-3xl font-black text-rose-400 mt-1 block">{stats.expiredCodes}</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900 border border-amber-900/40">
              <span className="text-xs text-amber-400 font-semibold block">Unverified Codes</span>
              <span className="text-2xl sm:text-3xl font-black text-amber-400 mt-1 block">{stats.unverifiedCodes}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-white text-sm">Engagement Stats</h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-800">
                  <span className="text-slate-400">Total Code Copies</span>
                  <span className="font-bold text-cyan-300">{stats.totalCopies}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-800">
                  <span className="text-slate-400">Estimated Page Views</span>
                  <span className="font-bold text-purple-300">{stats.totalPageViews}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-400">Total Published Articles</span>
                  <span className="font-bold text-white">{stats.totalArticles}</span>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="font-bold text-white text-sm">Recent Activity Stream</h3>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {stats.recentActivity.map(act => (
                  <div key={act.id} className="text-xs p-2 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between">
                    <span className="text-slate-300">{act.message}</span>
                    <span className="text-[10px] text-slate-500">{new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- ADD / EDIT CODE TAB --- */}
      {activeTab === 'add_code' && (
        <form onSubmit={handleSaveCode} className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5 max-w-3xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="font-extrabold text-white text-lg">
              {editingCodeId ? 'Edit Redeem Code' : 'Publish New Vidrush Code'}
            </h2>
            {editingCodeId && (
              <button
                type="button"
                onClick={() => { setEditingCodeId(null); setCodeForm({ code: '', title: '', slug: '', description: '', reward: '', status: 'Working', expires_at: '', featured: false, tags: 'Gems, Boosters' }); }}
                className="text-xs text-rose-400 hover:underline"
              >
                Cancel Edit
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Code String *</label>
              <input
                type="text"
                placeholder="e.g. VIDRUSH2026"
                value={codeForm.code}
                onChange={(e) => setCodeForm({ ...codeForm, code: e.target.value.toUpperCase() })}
                className="w-full bg-slate-950 text-cyan-300 font-mono font-bold text-sm p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-purple-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Title *</label>
              <input
                type="text"
                placeholder="e.g. Vidrush 2026 Celebration Package"
                value={codeForm.title}
                onChange={(e) => setCodeForm({ ...codeForm, title: e.target.value })}
                className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-purple-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Reward Summary *</label>
            <input
              type="text"
              placeholder="e.g. 500 Gems + 10,000 Gold Coins"
              value={codeForm.reward}
              onChange={(e) => setCodeForm({ ...codeForm, reward: e.target.value })}
              className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-purple-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Full Description</label>
            <textarea
              rows={3}
              placeholder="Detailed description of rewards and event origins..."
              value={codeForm.description}
              onChange={(e) => setCodeForm({ ...codeForm, description: e.target.value })}
              className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-purple-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Verification Status</label>
              <select
                value={codeForm.status}
                onChange={(e) => setCodeForm({ ...codeForm, status: e.target.value as CodeStatus })}
                className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
              >
                <option value="Working">Working</option>
                <option value="Expired">Expired</option>
                <option value="Unverified">Unverified</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Expiry Date (Optional)</label>
              <input
                type="date"
                value={codeForm.expires_at}
                onChange={(e) => setCodeForm({ ...codeForm, expires_at: e.target.value })}
                className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Tags (Comma Separated)</label>
              <input
                type="text"
                placeholder="Gems, Skin, Boosters"
                value={codeForm.tags}
                onChange={(e) => setCodeForm({ ...codeForm, tags: e.target.value })}
                className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="featured-check"
              checked={codeForm.featured}
              onChange={(e) => setCodeForm({ ...codeForm, featured: e.target.checked })}
              className="w-4 h-4 rounded bg-slate-950 border-slate-800 text-purple-600 focus:ring-purple-500"
            />
            <label htmlFor="featured-check" className="text-xs font-semibold text-slate-300">
              Mark as Featured Reward on Homepage
            </label>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-950 transition-colors"
          >
            {editingCodeId ? 'Update Redeem Code' : 'Publish Code'}
          </button>
        </form>
      )}

      {/* --- MANAGE CODES TAB --- */}
      {activeTab === 'manage_codes' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <input
              type="text"
              placeholder="Search code to manage..."
              value={manageSearch}
              onChange={(e) => setManageSearch(e.target.value)}
              className="w-full max-w-xs bg-slate-900 text-slate-200 text-xs p-2.5 rounded-xl border border-slate-800 focus:outline-none"
            />
            <span className="text-xs text-slate-400">Showing {filteredManageCodes.length} codes</span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="p-3">Code</th>
                  <th className="p-3">Title / Reward</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Last Verified</th>
                  <th className="p-3 text-right">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredManageCodes.map(code => (
                  <tr key={code.id} className="hover:bg-slate-950/40">
                    <td className="p-3 font-mono font-bold text-cyan-300 text-sm">{code.code}</td>
                    <td className="p-3">
                      <div className="font-bold text-white line-clamp-1">{code.title}</div>
                      <div className="text-[11px] text-purple-300 line-clamp-1">{code.reward}</div>
                    </td>
                    <td className="p-3">
                      <select
                        value={code.status}
                        onChange={(e) => handleStatusToggle(code, e.target.value as CodeStatus)}
                        className={`text-[10px] font-bold px-2 py-1 rounded-lg bg-slate-950 border focus:outline-none ${
                          code.status === 'Working' ? 'text-emerald-400 border-emerald-500/40' : code.status === 'Expired' ? 'text-rose-400 border-rose-500/40' : 'text-amber-400 border-amber-500/40'
                        }`}
                      >
                        <option value="Working">Working</option>
                        <option value="Expired">Expired</option>
                        <option value="Unverified">Unverified</option>
                      </select>
                    </td>
                    <td className="p-3 text-[11px] text-slate-400">
                      {new Date(code.verified_at).toLocaleDateString()}
                    </td>
                    <td className="p-3 text-right space-x-1.5">
                      <button
                        onClick={() => handleMarkVerifiedToday(code)}
                        className="px-2 py-1 rounded bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 hover:bg-emerald-900/60 text-[10px] font-bold"
                        title="Mark verified today"
                      >
                        Verify Today
                      </button>
                      <button
                        onClick={() => startEditCode(code)}
                        className="p-1 rounded bg-purple-950/60 border border-purple-800/60 text-purple-300 hover:bg-purple-900/60"
                        title="Edit code"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteCode(code.id, code.code)}
                        className="p-1 rounded bg-rose-950/60 border border-rose-800/60 text-rose-300 hover:bg-rose-900/60"
                        title="Delete code"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- ARTICLES TAB --- */}
      {activeTab === 'articles' && (
        <div className="space-y-6">
          <form onSubmit={handleSaveArticle} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 max-w-3xl">
            <h3 className="font-bold text-white text-base">
              {editingArticleId ? 'Edit Article' : 'Publish Guide Article'}
            </h3>
            <input
              type="text"
              placeholder="Article Title *"
              value={articleForm.title}
              onChange={(e) => setArticleForm({ ...articleForm, title: e.target.value })}
              className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
              required
            />
            <input
              type="text"
              placeholder="Short Excerpt *"
              value={articleForm.excerpt}
              onChange={(e) => setArticleForm({ ...articleForm, excerpt: e.target.value })}
              className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
            />
            <textarea
              rows={6}
              placeholder="Article Content (supports Markdown ### headings and paragraphs)..."
              value={articleForm.content}
              onChange={(e) => setArticleForm({ ...articleForm, content: e.target.value })}
              className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
              required
            />
            <input
              type="text"
              placeholder="Featured Image URL"
              value={articleForm.featured_image}
              onChange={(e) => setArticleForm({ ...articleForm, featured_image: e.target.value })}
              className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800 focus:outline-none"
            />
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-purple-600 text-white font-bold text-xs"
            >
              {editingArticleId ? 'Update Article' : 'Publish Article'}
            </button>
          </form>

          {/* List */}
          <div className="space-y-3">
            <h3 className="font-bold text-white text-sm">Published Guides ({articles.length})</h3>
            <div className="space-y-2">
              {articles.map(art => (
                <div key={art.id} className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{art.title}</div>
                    <div className="text-[10px] text-slate-400">{art.excerpt}</div>
                  </div>
                  <button
                    onClick={() => handleDeleteArticle(art.id, art.title)}
                    className="p-1.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-900"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* --- SITE SETTINGS TAB --- */}
      {activeTab === 'settings' && settingsForm && (
        <form onSubmit={handleSaveSettings} className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6 max-w-3xl">
          <h2 className="font-extrabold text-white text-lg border-b border-slate-800 pb-3">
            Site Configuration & AdSense Placement
          </h2>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Site Name</label>
              <input
                type="text"
                value={settingsForm.siteName}
                onChange={(e) => setSettingsForm({ ...settingsForm, siteName: e.target.value })}
                className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Independent Disclaimer Text</label>
              <textarea
                rows={3}
                value={settingsForm.disclaimerText}
                onChange={(e) => setSettingsForm({ ...settingsForm, disclaimerText: e.target.value })}
                className="w-full bg-slate-950 text-slate-200 text-xs p-3 rounded-xl border border-slate-800"
              />
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="font-bold text-white text-sm">AdSense & Display Ad Placement Slots</h3>
            
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-200">Header Banner Ad Slot</span>
                <input
                  type="checkbox"
                  checked={settingsForm.ads.headerBanner.enabled}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    ads: {
                      ...settingsForm.ads,
                      headerBanner: { ...settingsForm.ads.headerBanner, enabled: e.target.checked }
                    }
                  })}
                  className="w-4 h-4 rounded text-purple-600"
                />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-200">In-Content Ad Slot</span>
                <input
                  type="checkbox"
                  checked={settingsForm.ads.inContent.enabled}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    ads: {
                      ...settingsForm.ads,
                      inContent: { ...settingsForm.ads.inContent, enabled: e.target.checked }
                    }
                  })}
                  className="w-4 h-4 rounded text-purple-600"
                />
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-200">Footer Banner Ad Slot</span>
                <input
                  type="checkbox"
                  checked={settingsForm.ads.footerBanner.enabled}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    ads: {
                      ...settingsForm.ads,
                      footerBanner: { ...settingsForm.ads.footerBanner, enabled: e.target.checked }
                    }
                  })}
                  className="w-4 h-4 rounded text-purple-600"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-purple-600 text-white font-bold text-xs shadow-lg"
          >
            Save Site Settings
          </button>
        </form>
      )}
    </div>
  );
};
