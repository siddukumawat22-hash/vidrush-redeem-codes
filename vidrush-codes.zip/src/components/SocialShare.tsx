import React, { useState } from 'react';
import { Share2, Check, Link, MessageCircle, Send } from 'lucide-react';

interface SocialShareProps {
  title: string;
  url?: string;
  code?: string;
  onShowToast?: (msg: string, type?: 'success' | 'info') => void;
}

export const SocialShare: React.FC<SocialShareProps> = ({ title, url, code, onShowToast }) => {
  const [copied, setCopied] = useState(false);
  const shareUrl = url || window.location.href;

  const shareText = code
    ? `Claim working Vidrush redeem code: "${code}" for free rewards!`
    : title;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    if (onShowToast) onShowToast('Link copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsApp = () => {
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`, '_blank');
  };

  const handleTelegram = () => {
    window.open(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`, '_blank');
  };

  const handleTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
  };

  const handleFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank');
  };

  return (
    <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
      <div className="flex items-center gap-2 mb-3 text-xs font-bold text-slate-300 uppercase tracking-wider">
        <Share2 className="w-4 h-4 text-purple-400" /> Share with Friends
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={handleWhatsApp}
          className="px-3 py-2 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold hover:bg-emerald-600/30 flex items-center gap-1.5 transition-colors"
        >
          <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
        </button>
        <button
          onClick={handleTelegram}
          className="px-3 py-2 rounded-lg bg-sky-600/20 text-sky-400 border border-sky-500/30 text-xs font-semibold hover:bg-sky-600/30 flex items-center gap-1.5 transition-colors"
        >
          <Send className="w-3.5 h-3.5" /> Telegram
        </button>
        <button
          onClick={handleTwitter}
          className="px-3 py-2 rounded-lg bg-slate-800 text-slate-200 border border-slate-700 text-xs font-semibold hover:bg-slate-700 flex items-center gap-1.5 transition-colors"
        >
          <span className="font-bold text-xs">X</span> Twitter
        </button>
        <button
          onClick={handleFacebook}
          className="px-3 py-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 text-xs font-semibold hover:bg-blue-600/30 flex items-center gap-1.5 transition-colors"
        >
          Facebook
        </button>
        <button
          onClick={handleCopyLink}
          className="px-3 py-2 rounded-lg bg-purple-600/20 text-purple-300 border border-purple-500/30 text-xs font-semibold hover:bg-purple-600/30 flex items-center gap-1.5 transition-colors ml-auto"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Link className="w-3.5 h-3.5" />}
          {copied ? 'Copied' : 'Copy Link'}
        </button>
      </div>
    </div>
  );
};
