import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Search } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  category?: string;
}

const FAQ_LIST: FAQItem[] = [
  {
    question: 'How do I redeem a Vidrush code?',
    answer: 'To redeem a code, open the Vidrush application, log into your account, tap on your profile avatar at the top left, go to Settings -> Account Services -> Redeem Code, paste the code, and tap Confirm.'
  },
  {
    question: 'Why is my Vidrush code not working?',
    answer: 'A code may fail if it has expired, if it has reached its total global redemption cap, if there is a typo (codes are case-sensitive), or if you have already redeemed it on your account.'
  },
  {
    question: 'Are Vidrush codes case-sensitive?',
    answer: 'Yes, most Vidrush promotional codes require exact letter casing (usually all UPPERCASE like VIDRUSH2026). Always double-check before confirming.'
  },
  {
    question: 'How often are new Vidrush redeem codes released?',
    answer: 'New codes are typically released during game updates, monthly milestones, special streamer streams, holiday events, or milestone celebrations.'
  },
  {
    question: 'Can I redeem a code more than once per account?',
    answer: 'No, each Vidrush redeem code can only be claimed once per player account unless explicitly stated otherwise by developers.'
  },
  {
    question: 'Are the codes listed on Vidrush Codes official and safe?',
    answer: 'Yes! All codes published on our site are gathered from official game announcements, verified streams, and social media releases. We never ask for account passwords or payment details.'
  }
];

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [filterQuery, setFilterQuery] = useState('');

  const filteredFaqs = FAQ_LIST.filter(
    f => f.question.toLowerCase().includes(filterQuery.toLowerCase()) ||
         f.answer.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <section className="my-12">
      <div className="text-center max-w-2xl mx-auto mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20 mb-3">
          <HelpCircle className="w-3.5 h-3.5" /> FREQUENTLY ASKED QUESTIONS
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Everything You Need to Know
        </h2>
        <p className="text-slate-400 text-sm mt-2">
          Find answers regarding code redemption, validity, and account rewards.
        </p>

        {/* Filter input */}
        <div className="mt-4 relative max-w-md mx-auto">
          <input
            type="text"
            placeholder="Search questions..."
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            className="w-full bg-slate-900/50 border border-white/10 text-slate-100 placeholder-slate-500 text-xs pl-9 pr-4 py-2.5 rounded-full focus:outline-none focus:border-purple-500/50 transition-all backdrop-blur-md"
          />
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3.5 top-3" />
        </div>
      </div>

      <div className="max-w-3xl mx-auto space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            No matching questions found.
          </div>
        ) : (
          filteredFaqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md overflow-hidden transition-all hover:bg-slate-900/60 hover:border-white/20"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full text-left p-4.5 sm:p-5 flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-slate-200 hover:text-white"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-5 h-5 text-purple-400 shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                </button>
                {isOpen && (
                  <div className="px-4.5 pb-5 sm:px-5 sm:pb-5 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};
