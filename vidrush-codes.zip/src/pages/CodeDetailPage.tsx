import React, { useState, useEffect } from 'react';
import { Copy, Check, ShieldCheck, ArrowLeft, Calendar, Tag, Sparkles, HelpCircle, Gift, Info } from 'lucide-react';
import confetti from 'canvas-confetti';
import { RedeemCode } from '../types';
import { SocialShare } from '../components/SocialShare';
import { AdPlaceholder } from '../components/AdPlaceholder';
import { apiService } from '../services/api';

interface CodeDetailPageProps {
  code: RedeemCode;
  allCodes: RedeemCode[];
  onBack: () => void;
  onSelectCode: (code: RedeemCode) => void;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
}

export const CodeDetailPage: React.FC<CodeDetailPageProps> = ({
  code,
  allCodes,
  onBack,
  onSelectCode,
  onShowToast
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Inject JSON-LD Structured Data
    const schemaData = {
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'BreadcrumbList',
          'itemListElement': [
            { '@type': 'ListItem', 'position': 1, 'name': 'Home', 'item': window.location.origin },
            { '@type': 'ListItem', 'position': 2, 'name': 'Codes', 'item': `${window.location.origin}/codes` },
            { '@type': 'ListItem', 'position': 3, 'name': code.code, 'item': window.location.href }
          ]
        },
        {
          '@type': 'FAQPage',
          'mainEntity': [
            {
              '@type': 'Question',
              'name': `How do I redeem the Vidrush code ${code.code}?`,
              'acceptedAnswer': {
                '@type': 'Answer',
                'text': `Open Vidrush, tap your profile avatar, go to Settings -> Redeem Code, enter "${code.code}", and confirm.`
              }
            },
            {
              '@type': 'Question',
              'name': `What rewards does ${code.code} grant?`,
              'acceptedAnswer': {
                '@type': 'Answer',
                'text': code.reward
              }
            }
          ]
        }
      ]
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.id = 'code-detail-schema';
    script.text = JSON.stringify(schemaData);
    document.head.appendChild(script);

    return () => {
      const oldScript = document.getElementById('code-detail-schema');
      if (oldScript) oldScript.remove();
    };
  }, [code]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code.code);
    setCopied(true);
    onShowToast(`Copied code "${code.code}" to clipboard!`, 'success');

    try {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.7 },
        colors: ['#a855f7', '#38bdf8', '#34d399']
      });
    } catch {}

    apiService.trackCodeCopy(code.id);

    setTimeout(() => setCopied(false), 2500);
  };

  const relatedCodes = allCodes.filter(c => c.id !== code.id && c.status === 'Working').slice(0, 3);

  const formattedAddedDate = new Date(code.created_at).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  const formattedVerifiedDate = new Date(code.verified_at).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8 py-4">
      
      {/* Breadcrumb & Back */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-purple-600 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Back to Codes
        </button>

        <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-500">
          <span>Home</span> / <span>Codes</span> / <span className="text-purple-400">{code.code}</span>
        </div>
      </div>

      {/* Hero Code Box Card */}
      <div className="rounded-3xl bg-slate-900/40 border border-white/10 backdrop-blur-md p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                PROMO CODE
              </span>
              {code.status === 'Working' ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  ✓ WORKING & VERIFIED
                </span>
              ) : code.status === 'Expired' ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  EXPIRED
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  UNVERIFIED
                </span>
              )}
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Vidrush Redeem Code: {code.code}
            </h1>
          </div>
        </div>

        {/* Big Code Highlight & Copy Box */}
        <div className="p-4 sm:p-6 rounded-2xl bg-slate-950/60 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 my-6">
          <div className="text-center sm:text-left">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
              REDEEM CODE STRING
            </span>
            <div className="font-mono text-3xl sm:text-4xl font-extrabold text-cyan-300 tracking-wider select-all">
              {code.code}
            </div>
          </div>

          <button
            onClick={handleCopy}
            disabled={code.status === 'Expired'}
            className={`w-full sm:w-auto px-8 py-4 rounded-xl text-sm font-black tracking-wide transition-all duration-200 flex items-center justify-center gap-2 ${
              code.status === 'Expired'
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
                : copied
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-white text-slate-900 hover:bg-slate-200'
            }`}
          >
            {code.status === 'Expired' ? (
              'EXPIRED'
            ) : copied ? (
              <>
                <Check className="w-5 h-5 stroke-[3]" /> COPIED TO CLIPBOARD
              </>
            ) : (
              <>
                <Copy className="w-5 h-5" /> COPY REDEEM CODE
              </>
            )}
          </button>
        </div>

        {/* Verification Metadata Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-2xl bg-slate-950/40 border border-white/5 text-xs">
          <div>
            <span className="text-slate-500 text-[11px] block">Added Date</span>
            <span className="font-semibold text-slate-200">{formattedAddedDate}</span>
          </div>
          <div>
            <span className="text-slate-500 text-[11px] block">Last Verified</span>
            <span className="font-semibold text-emerald-400">{formattedVerifiedDate}</span>
          </div>
          <div>
            <span className="text-slate-500 text-[11px] block">Expiration</span>
            <span className="font-semibold text-slate-300">
              {code.expires_at ? new Date(code.expires_at).toLocaleDateString() : 'No expiry set'}
            </span>
          </div>
          <div>
            <span className="text-slate-500 text-[11px] block">Times Claimed</span>
            <span className="font-semibold text-purple-300">{code.copyCount || 0} copies</span>
          </div>
        </div>
      </div>

      {/* Ad Banner */}
      <AdPlaceholder />

      {/* REWARD DETAILS BREAKDOWN */}
      <div className="p-6 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md space-y-3">
        <div className="flex items-center gap-2 text-purple-400 font-bold text-sm uppercase tracking-wider">
          <Gift className="w-4 h-4" /> Reward Breakdown
        </div>
        <h2 className="text-xl font-bold text-white">
          What Do You Get With Code {code.code}?
        </h2>
        <p className="text-slate-300 text-sm leading-relaxed">
          {code.description}
        </p>
        <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-800/40 text-purple-200 text-xs font-semibold">
          🎁 Verified In-Game Grant: <span className="text-white font-bold">{code.reward}</span>
        </div>
      </div>

      {/* HOW TO REDEEM THIS SPECIFIC CODE */}
      <div className="p-6 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md space-y-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Info className="w-5 h-5 text-cyan-400" /> How to Redeem {code.code}
        </h2>
        <ol className="space-y-3 text-xs sm:text-sm text-slate-300 list-decimal pl-5 leading-relaxed">
          <li>Launch the <strong>Vidrush</strong> app on your Android or iOS device.</li>
          <li>Tap your <strong>Profile Icon</strong> in the top-left corner of the lobby screen.</li>
          <li>Select <strong>Settings</strong> and navigate to <strong>Redeem Code</strong> under Account Services.</li>
          <li>Copy code <code className="bg-slate-950 px-2 py-1 rounded text-cyan-300 font-mono">{code.code}</code> and paste it into the redemption box.</li>
          <li>Tap <strong>Confirm</strong> to instantly receive your rewards in your inventory or mailbox.</li>
        </ol>
      </div>

      {/* FREQUENTLY ASKED QUESTIONS */}
      <div className="p-6 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-purple-400" /> Frequently Asked Questions
        </h2>
        <div className="space-y-3 text-xs sm:text-sm text-slate-300">
          <div className="border-b border-white/5 pb-3">
            <p className="font-bold text-slate-100">Q: Why is code {code.code} giving an error?</p>
            <p className="text-slate-400 mt-1">
              Ensure you have typed the code in capital letters. Also verify that you haven't previously redeemed it on the same player account.
            </p>
          </div>
          <div>
            <p className="font-bold text-slate-100">Q: Are Vidrush redeem codes free?</p>
            <p className="text-slate-400 mt-1">
              Yes! All redeem codes on Vidrush Codes are 100% free and provided by developers for community rewards.
            </p>
          </div>
        </div>
      </div>

      {/* Social Sharing Component */}
      <SocialShare
        title={`Vidrush Redeem Code ${code.code}`}
        code={code.code}
        onShowToast={onShowToast}
      />

      {/* Related Codes */}
      {relatedCodes.length > 0 && (
        <div className="space-y-4 pt-4">
          <h3 className="font-bold text-white text-lg">Other Working Vidrush Codes</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {relatedCodes.map(rel => (
              <div
                key={rel.id}
                onClick={() => onSelectCode(rel)}
                className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-purple-600 transition-colors cursor-pointer"
              >
                <div className="font-mono font-bold text-cyan-300 text-sm">{rel.code}</div>
                <div className="text-xs text-slate-300 line-clamp-1 mt-1">{rel.title}</div>
                <div className="text-[11px] text-purple-400 font-semibold mt-2">View Code →</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
