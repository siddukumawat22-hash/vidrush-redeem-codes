import React, { useState } from 'react';
import { Search, Sparkles, Key, ShieldCheck, ArrowRight, BookOpen, Clock, Flame } from 'lucide-react';
import { RedeemCode, Article, SiteSettings, SearchFilters } from '../types';
import { CodeCard } from '../components/CodeCard';
import { HowToRedeem } from '../components/HowToRedeem';
import { FAQSection } from '../components/FAQSection';
import { AdPlaceholder } from '../components/AdPlaceholder';

interface HomePageProps {
  codes: RedeemCode[];
  articles: Article[];
  settings?: SiteSettings;
  onNavigate: (path: string) => void;
  onSelectCode: (code: RedeemCode) => void;
  onSelectArticle: (article: Article) => void;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  codes,
  articles,
  settings,
  onNavigate,
  onSelectCode,
  onSelectArticle,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<'All' | 'Working' | 'Expired' | 'Unverified'>('Working');
  const [searchQuery, setSearchQuery] = useState('');

  const workingCount = codes.filter(c => c.status === 'Working').length;
  const expiredCount = codes.filter(c => c.status === 'Expired').length;
  const unverifiedCount = codes.filter(c => c.status === 'Unverified').length;

  // Filter codes
  const filteredCodes = codes.filter(c => {
    const matchesTab = activeTab === 'All' || c.status === activeTab;
    const q = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !q ||
      c.code.toLowerCase().includes(q) ||
      c.title.toLowerCase().includes(q) ||
      c.reward.toLowerCase().includes(q) ||
      c.tags.some(t => t.toLowerCase().includes(q));
    return matchesTab && matchesQuery;
  });

  const featuredCodes = codes.filter(c => c.featured && c.status === 'Working');

  return (
    <div className="space-y-12">
      
      {/* HERO SECTION */}
      <section className="text-center py-10 sm:py-16 max-w-3xl mx-auto z-10 relative">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-purple-500/10 text-purple-300 border border-purple-500/20 mb-6 backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>DAILY VERIFIED REWARDS • 2026</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold mb-4 tracking-tight leading-tight">
          <span className="block text-white">Claim Your Rewards</span>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400">Vidrush Redeem Codes</span>
        </h1>

        <p className="text-slate-400 text-base sm:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
          Find the latest working Vidrush redeem codes, updated regularly with verified gems, coins, and speed boosters.
        </p>

        {/* Hero Search Box */}
        <div className="mt-6 max-w-xl mx-auto relative mb-8">
          <div className="flex items-center bg-slate-900/50 border border-white/10 backdrop-blur-md rounded-2xl p-2 focus-within:border-purple-500/50 transition-all shadow-xl">
            <Search className="w-5 h-5 text-purple-400 ml-3 shrink-0" />
            <input
              type="text"
              placeholder="Search code name or reward (e.g., VIDRUSH2026, Gems)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm sm:text-base px-3 py-1.5 focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-400 hover:text-white px-2"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Hero Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => {
              const el = document.getElementById('codes-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-8 py-3 bg-purple-600 hover:bg-purple-500 text-white font-semibold rounded-xl shadow-lg shadow-purple-900/20 flex items-center gap-2 transition-all"
          >
            <Key className="w-4 h-4" /> View Latest Codes
          </button>

          <button
            onClick={() => {
              const el = document.getElementById('how-to-redeem');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-8 py-3 bg-white/5 border border-white/10 hover:bg-white/10 text-white font-semibold rounded-xl backdrop-blur-md flex items-center gap-2 transition-all"
          >
            <BookOpen className="w-4 h-4 text-purple-400" /> How to Redeem
          </button>
        </div>

        {/* Quick Stats Banner */}
        <div className="mt-10 grid grid-cols-3 max-w-lg mx-auto divide-x divide-white/5 bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl p-4 text-center text-xs">
          <div>
            <span className="font-bold text-emerald-400 text-base sm:text-lg block">{workingCount}</span>
            <span className="text-slate-400 text-[11px]">Working Codes</span>
          </div>
          <div>
            <span className="font-bold text-purple-300 text-base sm:text-lg block">100%</span>
            <span className="text-slate-400 text-[11px]">Manually Verified</span>
          </div>
          <div>
            <span className="font-bold text-cyan-400 text-base sm:text-lg block">Free</span>
            <span className="text-slate-400 text-[11px]">Instant Rewards</span>
          </div>
        </div>
      </section>

      {/* Ad Placeholder Header Banner */}
      <AdPlaceholder config={settings?.ads?.headerBanner} />

      {/* FEATURED CODES CAROUSEL / GRID */}
      {featuredCodes.length > 0 && !searchQuery && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              <h2 className="text-xl font-extrabold text-white tracking-tight">
                Featured Active Rewards
              </h2>
            </div>
            <span className="text-xs text-purple-400 font-semibold">Hot Claims</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredCodes.map(code => (
              <CodeCard
                key={code.id}
                code={code}
                onSelectCode={onSelectCode}
                onShowToast={onShowToast}
              />
            ))}
          </div>
        </section>
      )}

      {/* CODES DIRECTORY SECTION */}
      <section id="codes-section" className="space-y-8 pt-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <span className="w-2.5 h-6 bg-purple-500 rounded-full"></span>
              Vidrush Redeem Codes Directory
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Currently featuring 1 active working code (<span className="text-emerald-400 font-mono font-bold">WANNERACADEMY</span>) and historical expired codes.
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
            {[
              { label: 'Working', val: 'Working', count: workingCount },
              { label: 'All', val: 'All', count: codes.length },
              { label: 'Expired', val: 'Expired', count: expiredCount },
              { label: 'Unverified', val: 'Unverified', count: unverifiedCount },
            ].map((tab) => (
              <button
                key={tab.val}
                onClick={() => setActiveTab(tab.val as any)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all border shrink-0 flex items-center gap-1.5 ${
                  activeTab === tab.val
                    ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-900/20'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  tab.val === 'Working'
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : tab.val === 'Expired'
                    ? 'bg-red-500/20 text-red-300'
                    : 'bg-white/10 text-slate-300'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* If searching, show filtered codes directly */}
        {searchQuery ? (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-300">
              Search Results for "{searchQuery}":
            </h3>
            {filteredCodes.length === 0 ? (
              <div className="text-center py-12 bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl">
                <p className="text-slate-400 font-semibold text-sm">No redeem codes match your search query.</p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="mt-3 px-4 py-2 rounded-xl bg-purple-600/30 border border-purple-500/40 text-purple-200 text-xs font-bold hover:bg-purple-600/50"
                >
                  Clear Search
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCodes.map(code => (
                  <CodeCard
                    key={code.id}
                    code={code}
                    onSelectCode={onSelectCode}
                    onShowToast={onShowToast}
                  />
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-10">
            {/* WORKING CODES SECTION */}
            {(activeTab === 'Working' || activeTab === 'All') && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 backdrop-blur-md">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <div>
                      <h3 className="text-base font-extrabold text-white tracking-wide flex items-center gap-2">
                        Working Codes
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                          {workingCount} ACTIVE
                        </span>
                      </h3>
                      <p className="text-[11px] text-slate-300">
                        Tested and verified live code. Copy and redeem in-game for instant rewards.
                      </p>
                    </div>
                  </div>
                  <span className="hidden sm:inline-block text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-lg border border-emerald-500/20">
                    100% Tested
                  </span>
                </div>

                {codes.filter(c => c.status === 'Working').length === 0 ? (
                  <div className="text-center py-8 bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl text-slate-400 text-xs">
                    No active working codes right now.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {codes.filter(c => c.status === 'Working').map(code => (
                      <CodeCard
                        key={code.id}
                        code={code}
                        onSelectCode={onSelectCode}
                        onShowToast={onShowToast}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* EXPIRED CODES SECTION */}
            {(activeTab === 'Expired' || activeTab === 'All') && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-red-950/30 border border-red-500/20 backdrop-blur-md">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-red-400" />
                    <div>
                      <h3 className="text-base font-extrabold text-white tracking-wide flex items-center gap-2">
                        Expired Codes
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-red-500/20 text-red-400 border border-red-500/30">
                          {expiredCount} EXPIRED
                        </span>
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        Historical demo and promotional vouchers that are no longer valid.
                      </p>
                    </div>
                  </div>
                  <span className="hidden sm:inline-block text-xs text-red-400 font-semibold">
                    Archive History
                  </span>
                </div>

                {codes.filter(c => c.status === 'Expired').length === 0 ? (
                  <div className="text-center py-8 bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl text-slate-400 text-xs">
                    No expired codes listed.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {codes.filter(c => c.status === 'Expired').map(code => (
                      <CodeCard
                        key={code.id}
                        code={code}
                        onSelectCode={onSelectCode}
                        onShowToast={onShowToast}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* UNVERIFIED CODES SECTION (IF SELECTED) */}
            {activeTab === 'Unverified' && (
              <div className="space-y-4">
                <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/20 backdrop-blur-md">
                  <h3 className="text-base font-extrabold text-white tracking-wide flex items-center gap-2">
                    Unverified Codes ({unverifiedCount})
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Codes submitted by users or pending developer verification.
                  </p>
                </div>
                {codes.filter(c => c.status === 'Unverified').length === 0 ? (
                  <div className="text-center py-8 bg-slate-900/40 border border-white/10 backdrop-blur-md rounded-2xl text-slate-400 text-xs">
                    No unverified codes pending.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {codes.filter(c => c.status === 'Unverified').map(code => (
                      <CodeCard
                        key={code.id}
                        code={code}
                        onSelectCode={onSelectCode}
                        onShowToast={onShowToast}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigate('/codes')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-bold text-white transition-all backdrop-blur-md"
          >
            Explore Complete Code Archive <ArrowRight className="w-4 h-4 text-purple-400" />
          </button>
        </div>
      </section>

      {/* Ad Placeholder In-Content */}
      <AdPlaceholder config={settings?.ads?.inContent} />

      {/* HOW TO REDEEM SECTION */}
      <div id="how-to-redeem">
        <HowToRedeem />
      </div>

      {/* LATEST GUIDES & ARTICLES PREVIEW */}
      {articles.length > 0 && (
        <section className="space-y-6 pt-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
                <span className="w-2 h-6 bg-blue-500 rounded-full"></span>
                Latest Game Guides & News
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Read our in-depth tutorials on redemption strategies and gem rewards.
              </p>
            </div>
            <button
              onClick={() => onNavigate('/guides')}
              className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1"
            >
              All Guides <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {articles.slice(0, 3).map((article) => (
              <div
                key={article.id}
                onClick={() => onSelectArticle(article)}
                className="group rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md overflow-hidden hover:bg-slate-900/60 hover:border-white/20 transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="h-40 overflow-hidden relative">
                    <img
                      src={article.featured_image}
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                  </div>
                  <div className="p-5">
                    <h3 className="font-bold text-white text-base group-hover:text-purple-300 transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                      {article.excerpt}
                    </p>
                  </div>
                </div>
                <div className="px-5 pb-5 pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-white/5 mt-2">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-purple-400" />
                    {new Date(article.created_at).toLocaleDateString()}
                  </span>
                  <span className="text-purple-400 font-semibold group-hover:underline">
                    Read Article →
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* FAQ SECTION */}
      <FAQSection />

      {/* Ad Placeholder Footer */}
      <AdPlaceholder config={settings?.ads?.footerBanner} />
    </div>
  );
};
