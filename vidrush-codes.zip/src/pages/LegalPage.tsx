import React, { useState } from 'react';
import { ShieldCheck, FileText, AlertTriangle, Mail, Send, CheckCircle2 } from 'lucide-react';

interface LegalPageProps {
  type: 'privacy-policy' | 'terms-and-conditions' | 'disclaimer' | 'contact-us';
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
}

export const LegalPage: React.FC<LegalPageProps> = ({ type, onShowToast }) => {
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMessage) {
      onShowToast('Please fill out all fields', 'info');
      return;
    }
    setSubmitted(true);
    onShowToast('Thank you! Your message has been sent.', 'success');
  };

  if (type === 'contact-us') {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center mx-auto text-purple-400">
            <Mail className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-extrabold text-white">Contact Vidrush Codes</h1>
          <p className="text-slate-400 text-sm">
            Have a new promo code to share or found an expired voucher? Send us a message below!
          </p>
        </div>

        {submitted ? (
          <div className="p-8 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center space-y-3 backdrop-blur-md">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="font-bold text-white text-lg">Message Received!</h3>
            <p className="text-xs text-slate-300">
              Our moderation team reviews code submissions daily. Thank you for contributing!
            </p>
            <button
              onClick={() => { setSubmitted(false); setContactMessage(''); }}
              className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs font-bold text-slate-300 hover:text-white"
            >
              Send Another Message
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitContact} className="p-6 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Your Name</label>
              <input
                type="text"
                placeholder="Gamer Username"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                className="w-full bg-slate-950/60 text-slate-200 text-xs p-3 rounded-xl border border-white/10 focus:outline-none focus:border-purple-500/50"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Your Email</label>
              <input
                type="email"
                placeholder="gamer@example.com"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                className="w-full bg-slate-950/60 text-slate-200 text-xs p-3 rounded-xl border border-white/10 focus:outline-none focus:border-purple-500/50"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Message / Code Submission</label>
              <textarea
                rows={4}
                placeholder="Provide code details, expiry reports, or feedback..."
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                className="w-full bg-slate-950/60 text-slate-200 text-xs p-3 rounded-xl border border-white/10 focus:outline-none focus:border-purple-500/50"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-purple-950"
            >
              <Send className="w-4 h-4" /> Send Message
            </button>
          </form>
        )}
      </div>
    );
  }

  if (type === 'disclaimer') {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6 text-slate-300 text-sm leading-relaxed">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <AlertTriangle className="w-8 h-8 text-amber-400 shrink-0" />
          <div>
            <h1 className="text-2xl font-extrabold text-white">Disclaimer</h1>
            <p className="text-xs text-slate-500">Independent Fan Directory & Informational Platform</p>
          </div>
        </div>

        <p>
          <strong>Vidrush Codes</strong> (vidrushcodes.com) is an independent rewards discovery platform and fan-curated database. We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with the official creators, developers, or publishers of <strong>Vidrush</strong>.
        </p>

        <h3 className="font-bold text-white text-base">No Account Credentials Requested</h3>
        <p>
          We never request account passwords, payment details, or personal sensitive information. All promotional vouchers listed on our website are collected from publicly available developer broadcasts, official social accounts, and gaming events.
        </p>

        <h3 className="font-bold text-white text-base">Trademarks & Copyrights</h3>
        <p>
          All product names, logos, brands, trademarks, and registered trademarks displayed on this site are property of their respective owners. Their mention does not imply any official affiliation or endorsement.
        </p>
      </div>
    );
  }

  if (type === 'terms-and-conditions') {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8 space-y-6 text-slate-300 text-sm leading-relaxed">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <FileText className="w-8 h-8 text-purple-400 shrink-0" />
          <div>
            <h1 className="text-2xl font-extrabold text-white">Terms & Conditions</h1>
            <p className="text-xs text-slate-500">Last updated: August 2026</p>
          </div>
        </div>

        <p>
          Welcome to <strong>Vidrush Codes</strong>. By accessing and using our platform, you agree to comply with and be bound by the following terms and conditions.
        </p>

        <h3 className="font-bold text-white text-base">1. Acceptable Usage</h3>
        <p>
          Vidrush Codes is provided solely for personal, non-commercial informational purposes. Users are prohibited from using automated scrapers, bots, or malicious scripts to overwhelm site infrastructure or generate invalid ad interactions.
        </p>

        <h3 className="font-bold text-white text-base">2. Accuracy of Redeem Codes</h3>
        <p>
          While our editorial team manually tests and verifies redeem codes regularly, developers reserve the right to expire, modify, or revoke voucher campaigns at any time without notice. We make no guarantees regarding code availability beyond our last verification timestamp.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 space-y-6 text-slate-300 text-sm leading-relaxed">
      <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
        <ShieldCheck className="w-8 h-8 text-emerald-400 shrink-0" />
        <div>
          <h1 className="text-2xl font-extrabold text-white">Privacy Policy</h1>
          <p className="text-xs text-slate-500">Your privacy and data protection standards</p>
        </div>
      </div>

      <p>
        At <strong>Vidrush Codes</strong>, accessible from vidrushcodes.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document outlines the types of information that is collected and recorded by Vidrush Codes and how we use it.
      </p>

      <h3 className="font-bold text-white text-base">Cookies and Advertising Partners</h3>
      <p>
        We may use compliant third-party advertising partners (such as Google AdSense) to display ads when you visit our website. These partners may use cookies to serve ads based on your visit to this and other websites on the Internet.
      </p>

      <h3 className="font-bold text-white text-base">Zero Personal Tracking</h3>
      <p>
        We do not force users to register, log in, or disclose personal identity to view and copy redeem codes.
      </p>
    </div>
  );
};
