import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';
import { HomePage } from './pages/HomePage';
import { CodesPage } from './pages/CodesPage';
import { CodeDetailPage } from './pages/CodeDetailPage';
import { GuidesPage } from './pages/GuidesPage';
import { GuideDetailPage } from './pages/GuideDetailPage';
import { FAQPage } from './pages/FAQPage';
import { AdminPage } from './pages/AdminPage';
import { LegalPage } from './pages/LegalPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { RedeemCode, Article, SiteSettings } from './types';
import { apiService } from './services/api';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(window.location.pathname);
  const [codes, setCodes] = useState<RedeemCode[]>([]);
  const [articles, setArticles] = useState<Article[]>([]);
  const [settings, setSettings] = useState<SiteSettings | undefined>(undefined);
  const [loading, setLoading] = useState<boolean>(true);

  // Selected item detail states
  const [selectedCode, setSelectedCode] = useState<RedeemCode | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  // Toast
  const [toast, setToast] = useState<{ message: string; type?: 'success' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    setToast({ message, type });
  };

  const loadAllData = async () => {
    try {
      const [codesRes, articlesRes, settingsRes] = await Promise.all([
        apiService.getCodes(),
        apiService.getArticles(),
        apiService.getSettings()
      ]);
      setCodes(codesRes.codes);
      setArticles(articlesRes);
      setSettings(settingsRes);
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();

    // Listen to browser back/forward buttons
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Sync route slug selection
  useEffect(() => {
    const path = currentPath;

    if (path.startsWith('/codes/') && path !== '/codes/' && path !== '/codes') {
      const slug = path.replace('/codes/', '');
      const found = codes.find(c => c.slug.toLowerCase() === slug.toLowerCase() || c.id === slug);
      if (found) setSelectedCode(found);
    } else {
      setSelectedCode(null);
    }

    if (path.startsWith('/guides/') && path !== '/guides/' && path !== '/guides') {
      const slug = path.replace('/guides/', '');
      const found = articles.find(a => a.slug.toLowerCase() === slug.toLowerCase() || a.id === slug);
      if (found) setSelectedArticle(found);
    } else {
      setSelectedArticle(null);
    }
  }, [currentPath, codes, articles]);

  const navigateTo = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCode = (code: RedeemCode) => {
    setSelectedCode(code);
    navigateTo(`/codes/${code.slug}`);
  };

  const handleSelectArticle = (article: Article) => {
    setSelectedArticle(article);
    navigateTo(`/guides/${article.slug}`);
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-4">
          <div className="w-12 h-12 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin" />
          <p className="text-xs font-semibold text-slate-400">Loading Vidrush Redeem Codes...</p>
        </div>
      );
    }

    // Code detail route
    if (currentPath.startsWith('/codes/') && selectedCode) {
      return (
        <CodeDetailPage
          code={selectedCode}
          allCodes={codes}
          onBack={() => navigateTo('/codes')}
          onSelectCode={handleSelectCode}
          onShowToast={showToast}
        />
      );
    }

    // Article detail route
    if (currentPath.startsWith('/guides/') && selectedArticle) {
      return (
        <GuideDetailPage
          article={selectedArticle}
          onBack={() => navigateTo('/guides')}
          onShowToast={showToast}
        />
      );
    }

    // Main Routes
    switch (currentPath) {
      case '/':
        return (
          <HomePage
            codes={codes}
            articles={articles}
            settings={settings}
            onNavigate={navigateTo}
            onSelectCode={handleSelectCode}
            onSelectArticle={handleSelectArticle}
            onShowToast={showToast}
          />
        );

      case '/codes':
        return (
          <CodesPage
            codes={codes}
            initialStatusFilter="All"
            onSelectCode={handleSelectCode}
            onShowToast={showToast}
          />
        );

      case '/working-codes':
        return (
          <CodesPage
            codes={codes}
            initialStatusFilter="Working"
            onSelectCode={handleSelectCode}
            onShowToast={showToast}
          />
        );

      case '/expired-codes':
        return (
          <CodesPage
            codes={codes}
            initialStatusFilter="Expired"
            onSelectCode={handleSelectCode}
            onShowToast={showToast}
          />
        );

      case '/guides':
        return (
          <GuidesPage
            articles={articles}
            onSelectArticle={handleSelectArticle}
          />
        );

      case '/faq':
        return <FAQPage />;

      case '/admin':
        return (
          <AdminPage
            onShowToast={showToast}
            onRefreshData={loadAllData}
          />
        );

      case '/privacy-policy':
        return <LegalPage type="privacy-policy" onShowToast={showToast} />;

      case '/terms-and-conditions':
        return <LegalPage type="terms-and-conditions" onShowToast={showToast} />;

      case '/disclaimer':
        return <LegalPage type="disclaimer" onShowToast={showToast} />;

      case '/contact-us':
        return <LegalPage type="contact-us" onShowToast={showToast} />;

      default:
        return <NotFoundPage onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 flex flex-col font-sans relative overflow-x-hidden selection:bg-purple-500 selection:text-white">
      {/* Background Frosted Ambient Glow Circles */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/20 blur-[120px] rounded-full pointer-events-none z-0" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/20 blur-[120px] rounded-full pointer-events-none z-0" />

      <Navbar
        currentPath={currentPath}
        onNavigate={navigateTo}
        onSearchSubmit={(q) => navigateTo(`/codes`)}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 z-10">
        {renderContent()}
      </main>

      <Footer onNavigate={navigateTo} settings={settings} />

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
