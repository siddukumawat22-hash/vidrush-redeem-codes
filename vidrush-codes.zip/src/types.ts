export type CodeStatus = 'Working' | 'Expired' | 'Unverified';

export interface RedeemCode {
  id: string;
  code: string;
  slug: string;
  title: string;
  description: string;
  reward: string;
  status: CodeStatus;
  created_at: string;
  updated_at: string;
  verified_at: string;
  expires_at?: string;
  featured: boolean;
  tags: string[];
  copyCount?: number;
  viewCount?: number;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  featured_image: string;
  seo_title: string;
  meta_description: string;
  tags: string[];
  published: boolean;
  created_at: string;
  updated_at: string;
}

export interface AdSlotConfig {
  enabled: boolean;
  codeSnippet?: string;
  type: 'banner' | 'in-content' | 'sidebar' | 'footer';
}

export interface SiteSettings {
  siteName: string;
  siteDescription: string;
  logoText: string;
  contactEmail: string;
  officialGameName: string;
  disclaimerText: string;
  socialLinks: {
    twitter?: string;
    telegram?: string;
    discord?: string;
    facebook?: string;
  };
  ads: {
    headerBanner: AdSlotConfig;
    inContent: AdSlotConfig;
    sidebar: AdSlotConfig;
    footerBanner: AdSlotConfig;
  };
}

export interface AnalyticsStats {
  totalCodes: number;
  workingCodes: number;
  expiredCodes: number;
  unverifiedCodes: number;
  totalArticles: number;
  totalCopies: number;
  totalPageViews: number;
  recentActivity: Array<{
    id: string;
    type: 'code_added' | 'code_copied' | 'code_verified' | 'article_published';
    message: string;
    timestamp: string;
  }>;
}

export interface SearchFilters {
  query: string;
  status: 'All' | CodeStatus;
  sortBy: 'newest' | 'recently_verified' | 'oldest';
  tag?: string;
}
