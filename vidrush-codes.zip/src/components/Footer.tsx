import React from 'react';
import { Key, ShieldAlert, Heart, ExternalLink } from 'lucide-react';
import { SiteSettings } from '../types';

interface FooterProps {
  onNavigate: (path: string) => void;
  settings?: SiteSettings;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, settings }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950/80 border-t border-white/5 backdrop-blur-xl text-slate-400 text-sm mt-16 z-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          
          {/* Brand Col */}
          <div className="md:col-span-1 space-y-4">
            <div 
              onClick={() => onNavigate('/')}
              className="flex items-center gap-2.5 cursor-pointer"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-400 p-0.5">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Key className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">
                Vidrush <span className="text-purple-400">Codes</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Your premier independent source for verified Vidrush redeem codes, reward vouchers, and step-by-step game progression guides.
            </p>
          </div>

          {/* Nav Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('/')} className="hover:text-purple-300 transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/codes')} className="hover:text-purple-300 transition-colors">
                  Latest Codes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/working-codes')} className="hover:text-purple-300 transition-colors">
                  Working Codes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/expired-codes')} className="hover:text-purple-300 transition-colors">
                  Expired Codes
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/guides')} className="hover:text-purple-300 transition-colors">
                  Redemption Guides
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/faq')} className="hover:text-purple-300 transition-colors">
                  FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Legal Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Legal & Support
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('/privacy-policy')} className="hover:text-purple-300 transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/terms-and-conditions')} className="hover:text-purple-300 transition-colors">
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/disclaimer')} className="hover:text-purple-300 transition-colors">
                  Disclaimer
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/contact-us')} className="hover:text-purple-300 transition-colors">
                  Contact Us
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('/admin')} className="hover:text-purple-300 transition-colors text-purple-400">
                  Admin Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Social & Disclaimer */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Community Channels
            </h4>
            <div className="flex items-center gap-2.5">
              {settings?.socialLinks?.twitter && (
                <a
                  href={settings.socialLinks.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-purple-950 hover:border-purple-600 transition-colors"
                  aria-label="X (Twitter)"
                >
                  <span className="font-bold text-xs">X</span>
                </a>
              )}
              {settings?.socialLinks?.telegram && (
                <a
                  href={settings.socialLinks.telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-purple-950 hover:border-purple-600 transition-colors"
                  aria-label="Telegram"
                >
                  <span className="font-bold text-xs">TG</span>
                </a>
              )}
              {settings?.socialLinks?.discord && (
                <a
                  href={settings.socialLinks.discord}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-purple-950 hover:border-purple-600 transition-colors"
                  aria-label="Discord"
                >
                  <span className="font-bold text-xs">DC</span>
                </a>
              )}
            </div>
            <div className="pt-2">
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                <span className="font-semibold text-slate-300 block mb-1 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-purple-400" /> Independent Notice
                </span>
                {settings?.disclaimerText || 'Vidrush Codes is an independent informational resource. All trademarks and game logos belong to their respective copyright holders.'}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© {currentYear} Vidrush Codes. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built for game enthusiasts with genuine values.
          </p>
        </div>
      </div>
    </footer>
  );
};
