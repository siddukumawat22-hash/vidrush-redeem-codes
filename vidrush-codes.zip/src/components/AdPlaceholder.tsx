import React from 'react';
import { AdSlotConfig } from '../types';

interface AdPlaceholderProps {
  config?: AdSlotConfig;
  className?: string;
}

export const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ config, className = '' }) => {
  // If ad slot is explicitly disabled by admin, render nothing
  if (config && !config.enabled) {
    return null;
  }

  // If custom ad snippet is provided by admin (e.g. Google AdSense script)
  if (config?.codeSnippet) {
    return (
      <div className={`my-6 text-center overflow-hidden ${className}`}>
        <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 block mb-1">
          ADVERTISEMENT
        </span>
        <div dangerouslySetInnerHTML={{ __html: config.codeSnippet }} />
      </div>
    );
  }

  // Default clean placeholder
  return (
    <div className={`my-6 p-4 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md text-center ${className}`}>
      <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 block mb-2">
        ADVERTISEMENT
      </span>
      <div className="py-6 border border-dashed border-white/10 rounded-xl bg-slate-950/40 text-xs text-slate-500 flex flex-col items-center justify-center gap-1">
        <span className="font-semibold text-slate-400">AdSense Display Area</span>
        <span className="text-[11px] text-slate-600">Compliant Advertising Container</span>
      </div>
    </div>
  );
};
