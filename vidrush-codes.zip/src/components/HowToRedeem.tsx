import React from 'react';
import { Smartphone, UserCheck, KeyRound, Gift } from 'lucide-react';

export const HowToRedeem: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Open Vidrush',
      description: 'Launch the Vidrush app on your mobile device or player and ensure you are logged in.',
      icon: Smartphone,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      num: '02',
      title: 'Navigate to Settings',
      description: 'Tap your profile avatar icon in the top left, then select the Settings (gear) option.',
      icon: UserCheck,
      color: 'from-indigo-500 to-cyan-500'
    },
    {
      num: '03',
      title: 'Enter Redeem Code',
      description: 'Find the "Redeem Code" section under Account Services and paste your code.',
      icon: KeyRound,
      color: 'from-cyan-500 to-emerald-500'
    },
    {
      num: '04',
      title: 'Claim Rewards',
      description: 'Tap Confirm to instantly receive your free gems, gold, and booster items.',
      icon: Gift,
      color: 'from-emerald-500 to-purple-500'
    }
  ];

  return (
    <section className="my-12">
      <div className="text-center max-w-2xl mx-auto mb-8">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center justify-center gap-2">
          <span className="w-2 h-6 bg-purple-500 rounded-full"></span>
          How to Redeem Vidrush Codes
        </h2>
        <p className="text-slate-400 text-sm mt-2">
          Follow these 4 simple steps to claim your free in-game gifts instantly.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.num}
              className="relative p-6 rounded-2xl bg-slate-900/40 border border-white/10 backdrop-blur-md hover:border-white/20 hover:bg-slate-900/60 transition-all group overflow-hidden"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${step.color} p-0.5 shadow-md`}>
                  <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                </div>
                <span className="font-mono text-2xl font-black text-slate-600 group-hover:text-purple-400 transition-colors">
                  {step.num}
                </span>
              </div>
              <h3 className="font-bold text-white text-base mb-1">
                {step.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {step.description}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
};
