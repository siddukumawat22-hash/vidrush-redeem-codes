import { RedeemCode, Article, SiteSettings } from '../types';

export const INITIAL_SETTINGS: SiteSettings = {
  siteName: 'Vidrush Codes',
  siteDescription: 'Find the latest working Vidrush redeem codes, updated daily with verified rewards and step-by-step redemption guides.',
  logoText: 'Vidrush Codes',
  contactEmail: 'support@vidrushcodes.com',
  officialGameName: 'Vidrush',
  disclaimerText: 'Vidrush Codes is an independent rewards and guide fan directory. We are not affiliated with, sponsored by, or officially connected with the creators or developers of Vidrush.',
  socialLinks: {
    twitter: 'https://x.com/vidrushcodes',
    telegram: 'https://t.me/vidrushcodes',
    discord: 'https://discord.gg/vidrush',
    facebook: 'https://facebook.com/vidrushcodes'
  },
  ads: {
    headerBanner: { enabled: true, type: 'banner' },
    inContent: { enabled: true, type: 'in-content' },
    sidebar: { enabled: true, type: 'sidebar' },
    footerBanner: { enabled: true, type: 'footer' }
  }
};

export const INITIAL_CODES: RedeemCode[] = [
  {
    id: 'code-wanner',
    code: 'WANNERACADEMY',
    slug: 'wanneracademy',
    title: 'Wanner Academy Official Redeem Code',
    description: 'Exclusive official Vidrush redeem code for Wanner Academy rewards and bonus packages.',
    reward: 'Exclusive Wanner Academy Bonus Rewards',
    status: 'Working',
    created_at: '2026-08-11T12:00:00.000Z',
    updated_at: '2026-08-11T20:00:00.000Z',
    verified_at: '2026-08-11T20:00:00.000Z',
    expires_at: '2027-12-31T23:59:59.000Z',
    featured: true,
    tags: ['WannerAcademy', 'Official', 'Working'],
    copyCount: 1520,
    viewCount: 4200
  },
  {
    id: 'code-1',
    code: 'VIDRUSH2026',
    slug: 'vidrush-2026',
    title: 'Vidrush 2026 Celebration Package',
    description: 'Historical promo package from early 2026.',
    reward: '500 Gems + 10,000 Coins + 2x XP Boost',
    status: 'Expired',
    created_at: '2026-08-01T10:00:00.000Z',
    updated_at: '2026-08-11T08:30:00.000Z',
    verified_at: '2026-08-11T12:00:00.000Z',
    expires_at: '2026-08-10T23:59:59.000Z',
    featured: false,
    tags: ['Gems', 'Boosters', 'Expired'],
    copyCount: 1420,
    viewCount: 3890
  },
  {
    id: 'code-2',
    code: 'VIPGIFT888',
    slug: 'vip-gift-888',
    title: 'VIP Reward Pass Code',
    description: 'Special VIP gift voucher unlocking exclusive character avatar frame and 250 Gems for active players.',
    reward: 'Exclusive Avatar Frame + 250 Gems',
    status: 'Expired',
    created_at: '2026-08-05T14:20:00.000Z',
    updated_at: '2026-08-11T09:15:00.000Z',
    verified_at: '2026-08-11T11:45:00.000Z',
    expires_at: '2026-08-10T23:59:59.000Z',
    featured: false,
    tags: ['VIP', 'Avatar', 'Expired'],
    copyCount: 980,
    viewCount: 2410
  },
  {
    id: 'code-3',
    code: 'SPEEDPASS99',
    slug: 'speed-pass-99',
    title: 'Speed Runner Starter Boost',
    description: 'Accelerate your game progression with 3 Speed Keys and 5,000 Bonus Gold.',
    reward: '3 Speed Keys + 5,000 Gold',
    status: 'Expired',
    created_at: '2026-08-08T09:00:00.000Z',
    updated_at: '2026-08-10T16:00:00.000Z',
    verified_at: '2026-08-10T16:00:00.000Z',
    expires_at: '2026-08-10T23:59:59.000Z',
    featured: false,
    tags: ['Keys', 'Gold', 'Expired'],
    copyCount: 650,
    viewCount: 1520
  },
  {
    id: 'code-4',
    code: 'CREATORRUSH',
    slug: 'creator-rush',
    title: 'Creator Network Exclusive Gift',
    description: 'Released during the official Vidrush Streamer Showcase. Grants 100 Gems and 1 Lucky Box.',
    reward: '100 Gems + 1 Lucky Box',
    status: 'Expired',
    created_at: '2026-08-09T18:00:00.000Z',
    updated_at: '2026-08-11T07:00:00.000Z',
    verified_at: '2026-08-11T07:00:00.000Z',
    expires_at: '2026-08-10T23:59:59.000Z',
    featured: false,
    tags: ['Streamer', 'Loot', 'Expired'],
    copyCount: 410,
    viewCount: 1100
  },
  {
    id: 'code-5',
    code: 'NEWPLAYER2026',
    slug: 'new-player-2026',
    title: 'New Player Welcome Package',
    description: 'Welcome bonus voucher for beginner accounts.',
    reward: '1,000 Starter Gems + 20,000 Gold',
    status: 'Expired',
    created_at: '2026-08-11T15:00:00.000Z',
    updated_at: '2026-08-11T15:00:00.000Z',
    verified_at: '2026-08-11T15:00:00.000Z',
    expires_at: '2026-08-11T20:00:00.000Z',
    featured: false,
    tags: ['Beginner', 'Expired'],
    copyCount: 120,
    viewCount: 340
  },
  {
    id: 'code-6',
    code: 'SUMMERVIBES25',
    slug: 'summer-vibes-25',
    title: 'Summer Event Special Voucher',
    description: 'Summer season launch event voucher that expired at the end of July 2026.',
    reward: 'Summer Skin + 300 Gems',
    status: 'Expired',
    created_at: '2026-06-01T00:00:00.000Z',
    updated_at: '2026-08-01T00:00:00.000Z',
    verified_at: '2026-08-01T00:00:00.000Z',
    expires_at: '2026-07-31T23:59:59.000Z',
    featured: false,
    tags: ['Skin', 'Event', 'Expired'],
    copyCount: 2300,
    viewCount: 5400
  },
  {
    id: 'code-7',
    code: 'SPRINGFEST2025',
    slug: 'spring-fest-2025',
    title: 'Spring Festival Celebration',
    description: 'Historical festival promo code from Spring 2025.',
    reward: '500 Gems + Spring Banner',
    status: 'Expired',
    created_at: '2025-03-15T00:00:00.000Z',
    updated_at: '2025-04-15T00:00:00.000Z',
    verified_at: '2025-04-15T00:00:00.000Z',
    expires_at: '2025-04-14T23:59:59.000Z',
    featured: false,
    tags: ['Festival', 'Historical', 'Expired'],
    copyCount: 3100,
    viewCount: 7800
  }
];

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    title: 'How to Redeem Vidrush Codes: Step-by-Step Guide',
    slug: 'how-to-redeem-vidrush-codes',
    excerpt: 'Learn the exact steps to claim free gems, coins, and exclusive skins in Vidrush on Android, iOS, and PC.',
    content: `Redeeming gift vouchers and promotional codes in **Vidrush** is simple once you know where to look inside the app interface. Follow this straightforward step-by-step tutorial to claim your free rewards.

### Step 1: Launch Vidrush & Log In
Open the Vidrush app on your mobile device or desktop player. Ensure you are signed into your primary player account so the rewards are credited directly to your inventory.

### Step 2: Open Account Settings
Tap on your profile avatar icon located in the upper-left corner of the main dashboard. In the drop-down menu, select **Settings** (gear icon).

### Step 3: Locate the Redeem Center
Inside the Settings panel, scroll down to the **Account & Services** section. Tap on the **Redeem Code** or **Gift Voucher** button.

### Step 4: Enter Your Code
Copy a verified active code from [Vidrush Codes](/) (e.g. \`WANNERACADEMY\`). Paste it into the text box. Pay close attention to capital letters, as Vidrush codes are case-sensitive.

### Step 5: Claim Your Inventory Items
Click **Confirm** or **Redeem**. Your rewards will instantly be delivered to your in-game Mailbox or directly credited to your gem balance!`,
    featured_image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'How to Redeem Vidrush Codes (2026 Step-by-Step Guide)',
    meta_description: 'Complete tutorial on how to redeem free Vidrush codes on Android, iOS, and desktop. Get instant gems and rewards.',
    tags: ['Guide', 'Redemption', 'Tutorial'],
    published: true,
    created_at: '2026-08-02T10:00:00.000Z',
    updated_at: '2026-08-11T10:00:00.000Z'
  },
  {
    id: 'art-2',
    title: 'Why Do Vidrush Codes Expire? (And How to Stay Updated)',
    slug: 'why-do-vidrush-codes-expire',
    excerpt: 'Ever wonder why a promo code stops working? Here is how redemption limits and time windows work in Vidrush.',
    content: `If you have ever attempted to claim a promotional voucher only to see an "Invalid or Expired Code" message, you are not alone. Understanding how Vidrush code lifecycles work helps you grab rewards before they run out.

### 1. Fixed Expiration Dates
Most codes are created for specific marketing campaigns, holiday events, or milestone celebrations (e.g. 1 Million Downloads). They come with a predetermined expiration date set by the publishers.

### 2. Global Redemption Caps
Certain high-tier codes (such as VIP passes or 1,000 Gem codes) have a total usage cap across all players worldwide (e.g. limited to the first 50,000 redemptions). Once that cap is met, the system marks the code as expired even if the end date has not passed.

### 3. Server-Side Regional Constraints
Occasion codes may be locked to specific regional game servers.

### How to Never Miss a Code
Bookmark **Vidrush Codes** and check back weekly. We test every code directly and mark non-working codes as Expired instantly.`,
    featured_image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Why Vidrush Codes Expire & Redemption Limits Explained',
    meta_description: 'Discover why Vidrush codes expire, global redemption caps, and tips to catch working promo codes first.',
    tags: ['Tips', 'Expiration', 'FAQ'],
    published: true,
    created_at: '2026-08-06T14:00:00.000Z',
    updated_at: '2026-08-11T10:00:00.000Z'
  },
  {
    id: 'art-3',
    title: 'Top 5 Vidrush Beginner Rewards & Free Gem Strategies',
    slug: 'top-5-vidrush-beginner-rewards',
    excerpt: 'Maximize your starting progress with these 5 essential beginner tips, daily gift codes, and achievement bonuses.',
    content: `Starting out in Vidrush can feel overwhelming with all the progression mechanics. Fortunately, utilizing early redemption codes gives you a massive advantage.

### 1. Redeem All Active Welcome Vouchers
Before spending any real currency, copy all codes marked as **Working** on our homepage. Codes like \`WANNERACADEMY\` grant starter rewards and special bonuses right off the bat.

### 2. Connect Social Accounts
Linking your profile to Discord or email often rewards an extra 200 free gems in your in-game mailbox.

### 3. Complete Daily Quests
Pair your 2x XP boosters from code rewards with daily quest completions to double your level progression rate.

### 4. Check In Daily for Calendar Rewards
Don't break your daily streak! Cumulative login rewards scale up significantly by week 3.`,
    featured_image: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1200&q=80',
    seo_title: 'Vidrush Beginner Guide: Best Free Rewards & Gems',
    meta_description: 'Essential beginner tips and codes to get free gems, gold, and XP boosters in Vidrush.',
    tags: ['Beginner', 'Gems', 'Strategy'],
    published: true,
    created_at: '2026-08-09T09:00:00.000Z',
    updated_at: '2026-08-11T10:00:00.000Z'
  }
];
